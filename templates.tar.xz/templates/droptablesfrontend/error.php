<?php
/**
 * Droptables
 *
 * We developed this code with our hearts and passion.
 * We hope you found it useful, easy to understand and to customize.
 * Otherwise, please feel free to contact us at contact@joomunited.com *
 *
 * @package   Droptables
 * @copyright Copyright (C) 2014 JoomUnited (http://www.joomunited.com). All rights reserved.
 * @copyright Copyright (C) 2014 Damien Barrère (http://www.crac-design.com). All rights reserved.
 * @license   GNU General Public License version 2 or later; http://www.gnu.org/licenses/gpl-2.0.html
 */

defined('_JEXEC') || die;

$app             = JFactory::getApplication();
$doc             = JFactory::getDocument();
$user            = JFactory::getUser();
$this->language  = $doc->language;
$this->direction = $doc->direction;

// Getting params from template
$params = $app->getTemplate(true)->params;

// Detecting Active Variables
$option   = $app->input->getCmd('option', '');
$view     = $app->input->getCmd('view', '');
$layout   = $app->input->getCmd('layout', '');
$task     = $app->input->getCmd('task', '');
$itemid   = $app->input->getCmd('Itemid', '');
$sitename = $app->get('sitename');

if ($task === 'edit' || $layout === 'form') {
    $fullWidth = 1;
} else {
    $fullWidth = 0;
}

// Add JavaScript Frameworks
JHtml::_('bootstrap.framework');

// Logo file or site title param
if ($params->get('logoFile')) {
    $logo = '<img src="' . JUri::root() . $params->get('logoFile') . '" alt="' . $sitename . '" />';
} elseif ($params->get('sitetitle')) {
    //phpcs:ignore PHPCompatibility.Constants.NewConstants.ent_html401Found -- Not support php version 5.4 or earlier
    $logo = '<span class="site-title" title="' . $sitename . '">' . htmlspecialchars($params->get('sitetitle'), ENT_COMPAT | ENT_HTML401, 'UTF-8') . '</span>';
} else {
    $logo = '<span class="site-title" title="' . $sitename . '">' . $sitename . '</span>';
}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>"
      lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>">
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <title><?php echo $this->title; ?><?php echo htmlspecialchars($this->error->getMessage(), ENT_QUOTES, 'UTF-8'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php // Use of Google Font ?>
    <?php if ($params->get('googleFont')) : ?>
        <link href='//fonts.googleapis.com/css?family=<?php echo $params->get('googleFontName'); ?>' rel='stylesheet'
              type='text/css'/>
        <style type="text/css">
            h1, h2, h3, h4, h5, h6, .site-title {
                font-family: '<?php echo str_replace('+', ' ', $params->get('googleFontName')); ?>', sans-serif;
            }
        </style>
    <?php endif; ?>
    <link rel="stylesheet"
          href="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template; ?>/css/template.css"
          type="text/css"/>
    <?php if ($app->get('debug_lang', '0') === '1' || $app->get('debug', '0') === '1') : ?>
        <link rel="stylesheet" href="<?php echo $this->baseurl; ?>/media/cms/css/debug.css" type="text/css"/>
    <?php endif; ?>
    <?php // If Right-to-Left ?>
    <?php if ($this->direction === 'rtl') : ?>
        <link rel="stylesheet" href="<?php echo $this->baseurl; ?>/media/com_dpe/jui/css/bootstrap-rtl.css" type="text/css"/>
    <?php endif; ?>
    <link href="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template; ?>/favicon.ico" rel="shortcut icon"
          type="image/vnd.microsoft.icon"/>
    <?php // Template color ?>
    <?php if ($params->get('templateColor')) : ?>
        <style type="text/css">
            body.site {
                border-top: 3px solid<?php echo $params->get('templateColor'); ?>;
                background-color: <?php echo $params->get('templateBackgroundColor'); ?>
            }

            a {
                color: <?php echo $params->get('templateColor'); ?>;
            }

            .navbar-inner, .nav-list > .active > a, .nav-list > .active > a:hover, .dropdown-menu li > a:hover, .dropdown-menu .active > a, .dropdown-menu .active > a:hover, .nav-pills > .active > a, .nav-pills > .active > a:hover {
                background: <?php echo $params->get('templateColor'); ?>;
            }

            .navbar-inner {
                -moz-box-shadow: 0 1px 3px rgba(0, 0, 0, .25), inset 0 -1px 0 rgba(0, 0, 0, .1), inset 0 30px 10px rgba(0, 0, 0, .2);
                -webkit-box-shadow: 0 1px 3px rgba(0, 0, 0, .25), inset 0 -1px 0 rgba(0, 0, 0, .1), inset 0 30px 10px rgba(0, 0, 0, .2);
                box-shadow: 0 1px 3px rgba(0, 0, 0, .25), inset 0 -1px 0 rgba(0, 0, 0, .1), inset 0 30px 10px rgba(0, 0, 0, .2);
            }
        </style>
    <?php endif; ?>
    <!--[if lt IE 9]>
    <script src="<?php echo $this->baseurl; ?>/media/com_dpe/jui/js/html5.js"></script>
    <![endif]-->
</head>

<body class="site <?php echo $option
                             . ' view-' . $view
                             . ($layout ? ' layout-' . $layout : ' no-layout')
                             . ($task ? ' task-' . $task : ' no-task')
                             . ($itemid ? ' itemid-' . $itemid : '')
                             . ($params->get('fluidContainer') ? ' fluid' : '');
?>">

<!-- Body -->
<div class="body">
    <div class="container<?php echo($params->get('fluidContainer') ? '-fluid' : ''); ?>">
        <!-- Header -->
        <header class="header" role="banner">
            <div class="header-inner clearfix">
                <a class="brand pull-left" href="<?php echo $this->baseurl; ?>/">
                    <?php echo $logo; ?>
                </a>
                <div class="header-search pull-right">
                    <?php // Display position-0 modules ?>
                    <?php echo $doc->getBuffer('modules', 'position-0', array('style' => 'none')); ?>
                </div>
            </div>
        </header>
        <div class="navigation">
            <?php // Display position-1 modules ?>
            <?php echo $doc->getBuffer('modules', 'position-1', array('style' => 'none')); ?>
        </div>
        <!-- Banner -->
        <div class="banner">
            <?php echo $doc->getBuffer('modules', 'banner', array('style' => 'xhtml')); ?>
        </div>
        <div class="row-fluid">
            <div id="content" class="span12">
                <!-- Begin Content -->
                <h1 class="page-header"><?php echo JText::_('JERROR_LAYOUT_PAGE_NOT_FOUND'); ?></h1>
                <div class="well">
                    <div class="row-fluid">
                        <div class="span6">
                            <p>
                                <strong><?php echo JText::_('JERROR_LAYOUT_ERROR_HAS_OCCURRED_WHILE_PROCESSING_YOUR_REQUEST'); ?></strong>
                            </p>
                            <p><?php echo JText::_('JERROR_LAYOUT_NOT_ABLE_TO_VISIT'); ?></p>
                            <ul>
                                <li><?php echo JText::_('JERROR_LAYOUT_AN_OUT_OF_DATE_BOOKMARK_FAVOURITE'); ?></li>
                                <li><?php echo JText::_('JERROR_LAYOUT_MIS_TYPED_ADDRESS'); ?></li>
                                <li><?php echo JText::_('JERROR_LAYOUT_SEARCH_ENGINE_OUT_OF_DATE_LISTING'); ?></li>
                                <li><?php echo JText::_('JERROR_LAYOUT_YOU_HAVE_NO_ACCESS_TO_THIS_PAGE'); ?></li>
                            </ul>
                        </div>
                        <div class="span6">
                            <?php if (JModuleHelper::getModule('search')) : ?>
                                <p><strong><?php echo JText::_('JERROR_LAYOUT_SEARCH'); ?></strong></p>
                                <p><?php echo JText::_('JERROR_LAYOUT_SEARCH_PAGE'); ?></p>
                                <?php echo $doc->getBuffer('module', 'search'); ?>
                            <?php endif; ?>
                            <p><?php echo JText::_('JERROR_LAYOUT_GO_TO_THE_HOME_PAGE'); ?></p>
                            <p><a href="<?php echo $this->baseurl; ?>/index.php" class="btn"><span
                                            class="icon-home"></span> <?php echo JText::_('JERROR_LAYOUT_HOME_PAGE'); ?>
                                </a></p>
                        </div>
                    </div>
                    <hr/>
                    <p><?php echo JText::_('JERROR_LAYOUT_PLEASE_CONTACT_THE_SYSTEM_ADMINISTRATOR'); ?></p>
                    <blockquote>
                        <span class="label label-inverse"><?php echo $this->error->getCode(); ?></span> <?php echo htmlspecialchars($this->error->getMessage(), ENT_QUOTES, 'UTF-8'); ?>
                    </blockquote>
                    <?php if ($this->debug) : ?>
                        <?php echo $this->renderBacktrace(); ?>
                    <?php endif; ?>
                </div>
                <!-- End Content -->
            </div>
        </div>
    </div>
</div>
<!-- Footer -->
<div class="footer">
    <div class="container<?php echo($params->get('fluidContainer') ? '-fluid' : ''); ?>">
        <hr/>
        <?php echo $doc->getBuffer('modules', 'footer', array('style' => 'none')); ?>
        <p class="pull-right">
            <a href="#top" id="back-top">
                <?php echo JText::_('TPL_DROPTABLES_BACKTOTOP'); ?>
            </a>
        </p>
        <p>
            &copy; <?php echo date('Y'); ?> <?php echo $sitename; ?>
        </p>
    </div>
</div>
<?php echo $doc->getBuffer('modules', 'debug', array('style' => 'none')); ?>
</body>
</html>
