<?php
/**
 * @package Tjlms
 * @copyright Copyright (C) 2009 -2010 Techjoomla, Tekdi Web Solutions . All rights reserved.
 * @license GNU GPLv2 <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>
 * @link     http://www.com
 */
defined('_JEXEC') or die('Restricted access');
use Joomla\CMS\Utility\Utility;
use Joomla\CMS\Language\Text;
use Joomla\CMS\HTML\HTMLHelper;

$subformat = '';

$cMax = (int) $comp_params->get('lesson_upload_size', '0', 'INT');
if(method_exists('Utility', 'getMaxUploadSize'))
{
	$cMax = Utility::getMaxUploadSize($cMax . 'MB');
}
$allowedFileSize = HTMLHelper::_('number.bytes', $cMax);

if (!empty($lesson->sub_format))
{
	$subformat = $lesson->sub_format;

	$subformat_source_options = explode('.', $subformat);
	$source_plugin = $subformat_source_options[0];
	$source_option = $subformat_source_options[1];

	if (!empty($source_option) && $source_plugin == 'boxapi2')
	{
		$path = JURI::base() .'index.php?option=com_tjlms&task=lesson.downloadMedia&mid=' . $lesson->media_id;
		$filepath = $lesson->org_filename;
		$filename = basename($filepath);
		?>
		<div class="col-sm-6 mb-20">
			<div>
				<label>
					<?php echo Text::_("COM_TJLMS_UPLOADED_FORMAT_FILE");?>
				</label>
			</div>
			<div>
				<a href="<?php echo $path ?>">
					<?php echo $filename ?>
				</a>
				<a class="btn btn-primary" onclick="tjlmsAdmin.lesson.preview('<?php echo $lesson_id?>')" title="<?php echo Text::_('COM_TJLMS_PREVIEW_LESSON_DESC');?>">
					<?php echo Text::_('COM_TJLMS_PREVIEW_LESSON');?>
				</a>
			</div>
		</div>
		<?php
	}
}
?>
<div class="col-sm-12 mb-20">
	<div class="col-sm-3">
		<label>
			<?php echo Text::_("COM_TJLMS_UPLOAD_FORMAT") ?>
		</label>
	</div>
	<div class="col-sm-9">
		<div class="document_upload">
			<div class="fileupload fileupload-new" data-provides="fileupload">
				<div class="input-append">
					<div class="uneditable-input w-100">
						<span class="fileupload-preview hidden-xs">
							<?php echo Text::sprintf('COM_TJLMS_UPLOAD_FILE_WITH_EXTENSION', 'pdf, docx, ppt, pptx, xlsx,xls', $cMax . ' MB');?>
						</span>
					</div>
					<span class="btn btn-file">
						<span class="fileupload-new">
							<?php echo Text::_("COM_TJLMS_BROWSE");?>
						</span>
						<input type="file"
							id="document_upload"
							name="lesson_format[<?php echo $plugin_name?>][document]"
							accept="pdf,docx,ppt,pptx,xlsx,xls"
							data-upload-ajax="1"
						/>
					</span>
				</div>
				<div class="fileupload-preview fs-12 visible-xs px-5">
					<?php echo Text::sprintf('COM_TJLMS_UPLOAD_FILE_WITH_EXTENSION', 'pdf, docx, ppt, pptx, xlsx,xls', $cMax . ' MB');?>
				</div>
			</div>
			<div style="clear:both"></div>
			<div class="format_upload_error alert alert-error" style="display:none" ></div>
			<div class="format_upload_success alert alert-info" style="display:none"></div>
		</div>
		<input type="hidden" id="uploded_lesson_file" name="uploded_lesson_file" value=""/>
		<input type="hidden" id="subformatoption" name="lesson_format[boxapi2][subformatoption]" value="upload"/>
	</div>
</div>
<div class="clearfix"></div>
<div>
	<?php
		echo Text::_('PLG_BOXAPI2_DOCUMENT_LIMITATION');
	?>
</div>

<script type="text/javascript">
/* Function to load the loading image. */
function validatedocumentboxapi2(formid,format,subformat,media_id)
{
	var res = {check: 1, message: "<?php echo Text::_('PLG_TJDOC_BOXAPI_VAL_PASSES');?>"};
	var main_format_form = techjoomla.jQuery("#lesson-format-form_"+ formid);

	if(media_id == 0)
	{
		if (!techjoomla.jQuery("#lesson-format-form_"+ formid + " #lesson_format #" + format + " #uploded_lesson_file").val())
		{
			var res = {check: 0, message: "<?php echo Text::_('PLG_TJDOCUMENT_BOXAPI2_FILE_MISSING');?>"};
		}
	}
	return res;
}


var tjlmsAdmin = {

	lesson: {

		preview: function (lessonId)
		{
			var lesson_preview_link = root_url+ "index.php?option=com_tjlms&view=lesson&tmpl=component&lesson_id=" +  lessonId + "&mode=preview&isAdmin=1" ;
			var wwidth = jQuery(window).width();
				var wheight = jQuery(window).height();
				SqueezeBox.open(lesson_preview_link, {
					handler: 'iframe',
					closable:false,
					size: {x: wwidth, y: wheight},
					//iframePreload:true,
					sizeLoading: { x: wwidth, y: wheight },
					classWindow: 'tjlms_lesson_screen',
					classOverlay: 'tjlms_lesson_screen_overlay',
				});
		}


	}
}

</script>

