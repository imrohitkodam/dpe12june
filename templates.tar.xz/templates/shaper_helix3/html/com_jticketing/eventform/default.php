<?php
/**
 * @package     JTicketing
 * @subpackage  com_jticketing
 *
 * @author      Techjoomla <extensions@techjoomla.com>
 * @copyright   Copyright (C) 2009 - 2021 Techjoomla. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\LayoutHelper;

HTMLHelper::_('behavior.tooltip');
HTMLHelper::_('behavior.formvalidation');
HTMLHelper::_('behavior.keepalive');
HTMLHelper::_('formbehavior.chosen', 'select');
HTMLHelper::_('behavior.multiselect');
HTMLHelper::_('behavior.modal', 'a.modal');
HTMLHelper::script('administrator/components/com_tjfields/assets/js/tjfields.js');

/** @var $this JticketingViewEventform */

if ($this->allowedToCreate == 1)
{
	if ($this->checkVendorApproval)
	{
		?>
		<div id="jtwrap" class="tjBs3 custom-create-event jt-custom-event">
		<?php
			if ($this->integration != 2)
			{
				?>
				<div class="alert alert-info alert-help-inline">
					<?php echo Text::_('COMJTICKETING_INTEGRATION_NATIVE_NOTICE');?>
				</div>
					<?php
					return false;
			}
			else
			{
				?>
				<div id="eventform1" class="row">
					<div class="col-xs-12">
						<div class="page-header">
							<h2>
								<?php
								if ($this->item->id)
								{
									echo Text::_('COM_JTICKETING_EDIT_EVENT');
									echo ':&nbsp' . $this->item->title;
								}
								else
								{
									echo Text::_('COM_JTICKETING_CREATE_NEW_EVENT');
								}
								?>
							</h2>
						</div>

						<?php

						if (($this->checkGatewayDetails == "true" && ($this->handle_transactions == 1 || in_array('adaptive_paypal', $this->adaptivePayment))) && $this->vendorCheck)
						{
							?>
							<div class="alert alert-warning">
								<?php
								$vendor_id = $this->vendorCheck;
								$link = 'index.php?option=com_tjvendors&view=vendor&layout=profile&client=com_jticketing';
								echo Text::_('COM_JTICKETING_PAYMENT_DETAILS_ERROR_MSG1');

								$itemid = JT::utilities()->getItemId($link);?>

								<a href="<?php echo JRoute::_($link . '&itemId=' . $itemid . '&vendor_id=' . $vendor_id, false); ?>" target="_blank">
									<?php echo Text::_('COM_JTICKETING_VENDOR_FORM_LINK'); ?>
								</a>

								<?php echo Text::_('COM_JTICKETING_PAYMENT_DETAILS_ERROR_MSG2'); ?>
							</div>
						<?php
						}
						?>

						<form id="adminForm" name="adminForm" action="" method="post" class="form-validate form-horizontal jt-event-view" enctype="multipart/form-data">
							<!--Tab Container start-->
							<div class="form-horizontal">
								<div class="row">
									<div class="col-xs-12  jt-event-frontend-edit">
									<!--tab 1 start-->
									<?php
										echo HTMLHelper::_('bootstrap.startTabSet', 'myTab', array('active' => 'details'));
									?>
										<?php
											echo HTMLHelper::_('bootstrap.addTab', 'myTab', 'details', Text::_('COM_JTICKETING_EVENT_TAB_DETAILS', true));
												echo HTMLHelper::_('bootstrap.startAccordion', 'myAccordian', array('active' => 'collapse1'));
												echo HTMLHelper::_('bootstrap.addSlide', 'myAccordian', Text::_('COM_JTICKETING_EVENT_TAB_BASIC'), 'collapse1', $class = '');
													echo $this->loadTemplate('details');
												echo HTMLHelper::_('bootstrap.endSlide');

												echo HTMLHelper::_('bootstrap.addSlide', 'myAccordian', Text::_('COM_JTICKETING_EVENT_TAB_LOCATION'), 'collapse2', $class='');
													echo $this->loadTemplate('location');
												echo HTMLHelper::_('bootstrap.endSlide');

												echo HTMLHelper::_('bootstrap.addSlide', 'myAccordian', Text::_('COM_JTICKETING_EVENT_TAB_TIME'), 'collapse3', $class='');
													echo $this->loadTemplate('booking');
													echo HTMLHelper::_('bootstrap.endSlide');
												echo HTMLHelper::_('bootstrap.endAccordion');
											echo HTMLHelper::_('bootstrap.endTab');
										?>
									<!--tab 1 end-->

									<!--tab 2 start-->
										<?php
										echo HTMLHelper::_('bootstrap.addTab', 'myTab', 'tickettypes', Text::_('COM_JTICKETING_EVENT_TAB_TICKET_TYPES', true));
													echo $this->form->getInput('tickettypes');
										?>
											<div class="row">
												<div class="col-sm-12">
													<?php
													if ( $this->params->get('siteadmin_comm_per') > 0 || $this->params->get('siteadmin_comm_flat') > 0)
													{
														?>
														<div id="commission">
															<span class="help-inline">
																<strong>
																	<?php echo Text::sprintf('COMMISSION_DEDUCTED_NOT_PERCENT', $this->params->get('siteadmin_comm_per'), '%');?>
																</strong>
															</span>

															<?php
															if ($this->params->get('siteadmin_comm_flat') > 0)
															{
																?>
																<span class="help-inline">
																	<strong>
																		<?php echo Text::sprintf('COMMISSION_DEDUCTED_NOT_FLAT', $this->params->get('siteadmin_comm_flat'), $this->params->get('currency'));?>
																	</strong>
																</span>
																<?php
															}
															?>
														</div>
													<?php
													}
													?>
												</div>
											</div>
										<?php
											echo HTMLHelper::_('bootstrap.endTab');
										?>
									<!--tab 2 end-->

									<!--tab 3 start-->
										<?php
										// Tab start for Attendee Fields.
											if ($this->collect_attendee_info_checkout)
											{
												echo HTMLHelper::_('bootstrap.addTab', 'myTab', 'attendeefields', Text::_('COM_JTICKETING_EVENT_TAB_EXTRA_FIELDS_ATTENDEE', true));
													echo $this->loadTemplate('attendee_core_fields');
													echo HTMLHelper::_('bootstrap.endTab');
											}
										?>
									<!--tab 3 end-->

									<!--tab 4 start-->
										<?php
										// TJ-Field Additional fields for Event
											if ($this->fieldsIntegration == 'com_tjfields')
											{
												echo HTMLHelper::_('bootstrap.addTab', 'myTab', 'extrafields', Text::_('COM_JTICKETING_EVENT_TAB_EXTRA_FIELDS', true));

												if ($this->formExtraFields && (!empty($this->item->id)))
												{
													// @TODO SNEHAL- Load layout for this
													echo $this->loadTemplate('extrafields');
												}
												else
												{
													?>
													<div class="alert alert-info">
														<?php echo Text::_('COM_JTICKETING_EVENT_EXTRA_DETAILS_SAVE_PROD_MSG');?>
													</div>
													<?php													
												}

												echo HTMLHelper::_('bootstrap.endTab');
											}
										?>
									<!--tab 4 end-->

									<!--tab 5 start-->
										<?php
										echo HTMLHelper::_('bootstrap.addTab', 'myTab', 'gallery', Text::_('COM_JTICKETING_EVENT_GALLERY', true));
										?>
											<div class="col-sm well">
												<div class="control-group">
													<div class="control-label"><?php echo $this->form->getLabel('gallery_file'); ?>				</div>
													<div class="controls">
														<?php echo $this->form->getInput('gallery_file'); ?>
													</div>
												</div>

												<div class="control-group">
													<div class="d-inline-block">
														<?php echo $this->form->renderField('gallery_link'); ?>
													</div>
													<div class="ml-15 gallary__validateBtn d-inline-block">
														<input type="button" class="validate_video_link" onclick="tjMediaFile.validateFile(this,1, <?php echo $this->isAdmin;?>, 'eventform')"
													value="<?php echo Text::_('COM_TJMEDIA_ADD_VIDEO_LINK');?>">
													</div>
												</div>
											</div>
											<div class="col-sm subform-wrapper">
												  <ul class="gallary__media thumbnails list-unstyled row d-flex flex-wrap">
													 <li class="gallary__media--li hide span2 col-md-4 col-sm-4 col-xs-12">
														<a class="close" onclick="tjMediaFile.tjMediaGallery.deleteMedia(this, <?php echo $this->isAdmin;?>, <?php echo (!empty($this->item->id))? $this->item->id : 0;?>, 'eventform');return false;">×</a>
														<?php HTMLHelper::_('jquery.token');	?>
														<input type="hidden" name="jform[gallery_file][media][]" class="media_field_value" value="">
														<div class="thumbnail"></div>
													 </li>
												  </ul>
											</div>
										<?php
											echo  HTMLHelper::_('bootstrap.endTab');
										?>
									<!--tab 5 end-->

									<!--tab 6 start-->
										<?php
											// Loading joomla's params layout to show the fields and field group added for the event.
											echo LayoutHelper::render('joomla.edit.params', $this);
										?>
									<!-- tab 6 end-->
									<?php echo HTMLHelper::_('bootstrap.endTabSet'); ?>
								</div>

								<!--Tab Container closed-->

								<div class="mt-10 pull-right mr-10 mb-30">
									<button type="button" class="btn btn-default btn-primary com_jticketing_margin validate"
									onclick="Joomla.submitbutton('eventform.save')">
										<span><?php echo Text::_('JSUBMIT'); ?></span>
									</button>

									<button type="button" class="btn btn-default com_jticketing_margin"
									onclick="Joomla.submitbutton('eventform.cancel')">
										<span><?php echo Text::_('JCANCEL'); ?></span>
									</button>
								</div>

								<input type="hidden" name="option" value="com_jticketing" />
								<input type="hidden" name="task" id="task" value="eventform.save" />

								<input type="hidden" name="id"
									value="<?php if (!empty($this->item->id)) echo $this->item->id; ?>"/>

								<input type="hidden" name="jform[id]"
									value="<?php if (!empty($this->item->id)) echo $this->item->id;?>"/>

								<input type="hidden" name="jform[created_by]"
									value="<?php echo $this->item->created_by ? $this->item->created_by:Factory::getUser()->id;?>" />

								<?php echo HTMLHelper::_('form.token'); ?>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
			<?php
		}
	}
	else
	{
		?>
		<div class="alert alert-info">
			<?php echo Text::_('COM_JTICKETING_VENDOR_NOT_APPROVED_MESSAGE');?>
		</div>
		<?php
	}
}
else
{
	?>
	<div class="alert alert-info alert-help-inline">
		<?php echo Text::_('COM_JTICKETING_VENDOR_ENFORCEMENT_ERROR');?>
		<?php echo Text::_('COM_JTICKETING_VENDOR_ENFORCEMENT_EVENT_REDIRECT_MESSAGE');?>
	</div>

	<div>
		<a href="<?php echo JRoute::_('index.php?option=com_tjvendors&view=vendor&layout=edit&client=com_jticketing');?>" target="_blank" >
			<button class="btn btn-primary">
				<?php echo Text::_('COM_JTICKETING_VENDOR_ENFORCEMENT_EVENT_REDIRECT_LINK'); ?>
			</button>
		</a>
	</div>
	<?php
}


$mediaGalleryObj = 0;

if (!empty($this->item->gallery))
{
	$mediaGalleryObj = json_encode($this->item->gallery);
}
?>

<script type="text/javascript">
	var existing_url = '<?php echo $this->event->getOnlineEventId(); ?>';
	var silentVendor = '<?php echo $this->silentVendor; ?>';
	var eventId = '<?php echo $this->item->id; ?>';

	<?php
	if ($this->item->venue != 0)
	{
		?>
		var venueName = "<?php echo htmlspecialchars($this->venueName);?>";
		<?php
	}
	?>

	var root_url = '<?php echo JUri::root(); ?>';
	var venueId = '<?php echo $this->venueId;?>';
	var mediaSize = '<?php echo $this->mediaSize;?>';
	var mediaGallery = <?php echo $mediaGalleryObj;?>;
	var galleryImage = '<?php echo $this->eventGalleryImage;?>';
	var eventMainImage = '<?php echo $this->eventMainImage;?>';
	var enableOnlineEvents = '<?php echo $this->onlineEvents;?>';
	var jticketing_baseurl = '<?php echo JUri::root(); ?>';
	var enableOnlineVenues = '<?php echo $this->enableOnlineVenues;?>';
	var descriptionError = '<?php echo Text::_('COM_JTICKETING_EMPTY_DESCRIPTION_ERROR');?>';
	var vendor_id = '<?php echo $this->vendorCheck;?>';
	var selectedVenue = '<?php echo $this->item->venue;?>';
	var tncForCreateEvent = '<?php echo $this->tncForCreateEvent;?>';
	var oldEventStartDate = "<?php echo HTMLHelper::date($this->item->startdate,'Y-m-d H:i', true);?>";
	var oldEventEndDate = "<?php echo HTMLHelper::date($this->item->enddate,'Y-m-d H:i', true);?>";
	jtSite.eventform.initEventJs();
	validation.positiveNumber();
</script>
<script>
jQuery(document).ready(function()
{
	/* It restrict the user for manual input in datepicker field */
	jQuery(document).delegate('.inputbox-date', 'focusin', function(event) {
		event.preventDefault();
		jQuery(this).parent().siblings(':eq(0)').show();
	});

	jQuery(document).delegate('.inputbox-date', 'keydown contextmenu', function() {
			return false;
	});
});
</script>

<?php
if (!$this->accessLevel)
{
	?>
	<style>
		.subform-repeatable-group .form-group:nth-last-child(2){
		display: none;
		}

		.subform-repeatable-group .form-group:last-child{
		display: none;
	}
	</style>
	<?php
}
$ticketAccess = JT::config()->get('ticket_access');
$document = Factory::getDocument();
$document->addScriptDeclaration('var ticketAccessState = "' . $ticketAccess . '";');?>
