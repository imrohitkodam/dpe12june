<?php
/**
 * @package     JTicketing
 * @subpackage  com_jticketing
 *
 * @author      Techjoomla <extensions@techjoomla.com>
 * @copyright   Copyright (C) 2009 - 2021 Techjoomla. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Factory;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Language\Text;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Layout\FileLayout;
use Joomla\CMS\Filter\InputFilter;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\CMS\Component\ComponentHelper;

HTMLHelper::_('behavior.modal', 'a.modal');
HTMLHelper::_('stylesheet', 'media/jui/css/bootstrap.min.css', false);
HTMLHelper::_('jquery.token');
jimport('techjoomla.common');
$this->techjoomlacommon = new TechjoomlaCommon;
JticketingCommonHelper::getLanguageConstant();
$eventUrl          = 'index.php?option=com_jticketing&view=event&id=' . (int) $this->item->id;
$eventUrl          = Uri::root() . substr(Route::_($eventUrl), strlen(Uri::base(true)) + 1);
$document          = Factory::getDocument();

// Load Chart Javascript Files.
$document->addScript(Uri::root(true) . '/media/com_jticketing/vendors/js/Chart.min.js');
$document->addscript(Uri::root(true) . '/media/com_jticketing/vendors/js/jquery.countdown.min.js');

if (!empty($this->item->coverImage))
{
	$imagePath = $this->item->coverImage->media;
}
elseif (!empty($this->item->image))
{
	$imagePath = $this->item->image->media;
}
else
{
	$imagePath = Route::_(Uri::base() . 'media/com_jticketing/images/default-event-image.png');
}
?>
<div class="col-xs-12 tjBs3" id="jtwrap">
	<div class="eventDetails">
		<?php
		if ($this->item->created_by == $this->userid)
		{
			?>
			<!--Event performance map-->
			<div class="eventDetails-chart">
				<div class="clearfix">
					<div class="pull-right">
						<select id='event-graph-period'>
							<option value ='0'><?php echo Text::_('COM_JTICKETING_FILTER_LATEST');?></option>
							<option value ='1'><?php echo Text::_('COM_JTICKETING_FILTER_LAST_MONTH');?></option>
							<option value ='2'><?php echo Text::_('COM_JTICKETING_FILTER_LAST_YEAR');?></option>
						</select>
					</div>
				</div>
				<div>
					<canvas id="myevent_graph"></canvas>
				</div>
			</div>
			<!--Event performance map end-->
			<?php
		}
		else
		{
			?>
			<!--Event image-->
			<div class="eventDetails-banner" style="background-image:url('<?php echo $imagePath;?>');"></div>
			<!--Event image end-->
			<?php
		}
		?>

		<!--Event date, name, organizer, book button-->
		<div class="eventDetails-meta">
			<div class="eventDetails-time hidden-xs">
				<h4 class="m-0">
					<strong class="d-block mb-5">
						<?php echo HTMLHelper::date($this->item->startdate, Text::_("COM_JTICKETING_DATE_FORMAT_EVENT_DETAIL_DATE"), true);?>
					</strong>
					<?php echo HTMLHelper::date($this->item->startdate, Text::_("COM_JTICKETING_DATE_FORMAT_EVENT_DETAIL_MONTH"), true);?>
				</h4>
			</div>

			<!--Event Title start-->
			<div class="eventDetails-title mt-15">
				<h1 class="mt-0 font-bold h2 text-left">
					<?php
					if ($this->item->created_by == $this->userid)
					{
						$editEventlink = Route::_('index.php?option=com_jticketing&task=eventform.edit&id=' . $this->item->id . '&Itemid=' . $this->createEventItemid, false);
						?>

							<a id="eventEdit" href="<?php echo $editEventlink?>" title="<?php echo Text::_('COM_JTICKETING_EDIT_EVENT_LINK')?>">
									<?php echo $this->escape($this->item->title);?>
							<small>
								<i class="fa fa-pencil-square-o" aria-hidden="true"></i>
							</small>
							</a>
						<?php
					}
					else
					{
						echo $this->escape($this->item->title);
					}
					?>
				</h1>
			</div>
			<!--Event Title end-->

			<!--Event Organizer start-->
			<div class="eventDetails-organizer text-muted">
				<?php
				$userinfo = Factory::getUser($this->item->created_by);
				echo Text::_('COM_JTICKETING_EVENT_DETAIL_ORGANIZER_BY') . ' ' . $userinfo->name;

				if ($this->item->organizerProfileUrl)
				{
					echo '<br/>'; ?>
							<a href="<?php echo $this->item->organizerProfileUrl;?>">
								<?php echo ucfirst(Text::_('COM_JTICKETING_EVENT_ORGANIZER_DETAILS'));?>
							</a>
					<?php
				}
					?>
			</div>
			<!--Event Organizer end-->

			<!----Price---->
			<div class="eventDetails-price h4">
				<?php
				if (($this->item->eventPriceMaxValue == $this->item->eventPriceMinValue) AND (($this->item->eventPriceMaxValue == 0)
							AND ($this->item->eventPriceMinValue == 0)))
				{
						?>
					<strong>
						<?php echo strtoupper(Text::_('COM_JTICKETING_ONLY_FREE_TICKET_TYPE'));?>
					</strong>
					<?php
				}
				elseif (($this->item->eventPriceMaxValue == $this->item->eventPriceMinValue) AND
							(($this->item->eventPriceMaxValue != 0) AND ($this->item->eventPriceMinValue != 0)))
				{
					?>
					<strong>
						<?php echo $this->utilities->getFormattedPrice($this->item->eventPriceMaxValue);?>
					</strong>
					<?php
				}
				elseif (($this->item->eventPriceMaxValue == 1) AND ($this->item->eventPriceMinValue == -1))
				{
					?>
					<strong>
						<?php echo strtoupper(Text::_('COM_JTICKETING_HOUSEFULL_TICKET_TYPE'));?>
					</strong>
					<?php
				}
				else
				{
					?>
					<strong>
						<?php
						echo $this->utilities->getFormattedPrice($this->item->eventPriceMinValue);
						echo ' - ';
						echo $this->utilities->getFormattedPrice($this->item->eventPriceMaxValue);
								?>
					</strong>
					<?php
				}
				?>
			</div>
			<!----Price end---->

			<!-- Action Button code Start-->
			<div class="row mt-auto">
				<div class="col-xs-12">
					<div class="ticketBookBtn">
						<?php echo LayoutHelper::render('event.actions', $this->event); ?>
					</div>
				</div>
				<div class="hidden-xs mt-5 col-xs-12">
					<?php
					$this->currentTime = Factory::getDate()->toSql();

					$booking_start_date = ($this->item->booking_start_date != '0000-00-00 00:00:00') ?
					$this->item->booking_start_date : $this->item->created;

					$booking_end_date = ($this->item->booking_end_date != '0000-00-00 00:00:00') ?
					$this->item->booking_end_date : $this->item->enddate;

					if ($booking_start_date > $this->currentTime)
					{
						echo Text::_('COM_JTICKETING_EVENTS_BOOKING_WILL_START');
						echo $bookingStartDate = $this->utilities->getFormatedDate($booking_start_date);
					}
					elseif ($booking_end_date < $this->currentTime)
					{
						echo Text::_('COM_JTICKETING_EVENTS_BOOKING_IS_CLOSED');
					}
					else
					{
						echo Text::_('COM_JTICKETING_EVENTS_BOOKING_WILL_CLOSED');
						echo $bookingEndDate = $this->utilities->getFormatedDate($booking_end_date);
					}
					?>
				</div>
			</div>
			<!--Action Button code end here-->
			<div class="clearfix"></div>
		</div>
	</div>
	<!--Event date, name, organizer, book button end -->

	<div class="row eventDetails-body">
		<div class="col-sm-4 col-sm-push-8 eventDetails-venue">

			<!--Event location and time-->
			<?php echo $this->loadTemplate("eventdatetime"); ?>
			<!--Event location and time-->

			<!--Sharing Option start-->
			<div class="row">
				<div class="col-xs-12">
					<div class="socialSharing eventDetails-socialSharing">
						<?php
						if ($this->params->get('social_sharing'))
						{
							echo '<div id="fb-root"></div>';
							$fbLikeTweet = Uri::root() . 'media/com_jticketing/js/fblike.js';
							echo "<script type='text/javascript' src='" . $fbLikeTweet . "'></script>";

							// Set metadata
							$config = Factory::getConfig();
							$siteName = $config->get('sitename');
							$document->addCustomTag('<meta property="og:title" content="' . $this->escape($this->item->title) . '" />');
							$document->addCustomTag('<meta property="og:image" content="' . $imagePath . '" />');
							$document->addCustomTag('<meta property="og:url" content="' . $eventUrl . '" />');
							$document->addCustomTag('<meta property="og:description" content="' . nl2br($this->escape($this->item->short_description)) . '" />');
							$document->addCustomTag('<meta property="og:site_name" content="' . $this->siteName . '" />');
							$document->addCustomTag('<meta property="og:type" content="event" />');
							$pid = $this->params->get('addthis_publishid');

							if ($this->params->get('social_shring_type') == 'addthis')
							{
								$addThisShare = '
								<div class="addthis_toolbox addthis_default_style">
								<a class="addthis_button_facebook_like" fb:like:layout="button_count" class="addthis_button" addthis:url="' . $eventUrl . '"></a>
								<a class="addthis_button_google_plusone" g:plusone:size="medium" class="addthis_button" addthis:url="' . $eventUrl . '"></a>
								<a class="addthis_button_tweet" class="addthis_button" addthis:url="' . $eventUrl . '"></a>
								<a class="addthis_button_pinterest_pinit" class="addthis_button" addthis:url="' . $eventUrl . '"></a>
								<a class="addthis_counter addthis_pill_style" class="addthis_button" addthis:url="' . $eventUrl . '"></a>
								</div>
								<script type="text/javascript">
									var addthis_config ={ pubid: "' . $pid . '"};
								</script>
								<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid="' . $pid . '"></script>';

								$addThisJs = 'http://s7.addthis.com/js/300/addthis_widget.js';
								$this->techjoomlacommon->loadScriptOnce($addThisJs);

								/*output all social sharing buttons*/
								echo' <div id="rr" style="">
									<div class="social_share_container">
									<div class="social_share_container_inner">' .
										$addThisShare .
									'</div>
								</div>
								</div>
								';
							}
							else
							{
								echo '<div class="com_jticketing_horizontal_social_buttons mr-10 mt-5">';
								echo '<div class="float-left">
										<div class="fb-like" style=" display: inline-grid" data-href="' . $eventUrl . '" data-send="true" data-layout="button_count" data-width="450" data-show-faces="true">
										</div>
									  </div>';

								echo '<div class="float-left">
										&nbsp; <div class="g-plus" data-action="share" data-annotation="bubble" data-href="' . $eventUrl . '"></div>
									  </div>';
								echo '<div class="float-left">
											&nbsp; <a href="https://twitter.com/share" class="twitter-share-button" data-url="' . $eventUrl . '" data-counturl="' . $eventUrl . '"  data-lang="en">Tweet</a>
										  </div>';
								echo '</div>
									<div class="com_jticketing_clear_both"></div>';
							}
						}
						?>
						<div class="clearfix"></div>

						<!--Like Dislike Option-->
						<?php
						if (file_exists(JPATH_SITE . '/' . 'components/com_jlike/helper.php'))
						{
							$this->showComments = -1;
							$this->showLikeButtons = 1;
							$jLikeUrl = 'index.php?option=com_jticketing&view=event&id=' . (int) $this->item->id;

							echo LayoutHelper::render('event.like_buttons', $this->item, JPATH_SITE . '/' . 'components/com_jticketing/layouts',  array('eventUrl' => $eventUrl, 'show_comments' => $this->showComments, 'show_like_buttons' => $this->showLikeButtons));
						}
						?>
					</div>
				</div>
			</div>

			<!--Sharing Option End-->
			<!--Event tags if no description-->
			<div class="row">
				<div class="col-xs-12">
					<div class="mt-15">
						<?php
						if (empty($this->item->long_description) && $this->enable_tags == 1
							&& $this->redirect_tags_to_events == 0 && !empty($this->item->tags->itemTags))
						{
							?>
							<?php $this->item->tagLayout = new JLayoutFile('joomla.content.tags');?>
							<?php echo ($this->item->tagLayout->render($this->item->tags->itemTags));?>
							<?php
						}

						if (empty($this->item->long_description) && $this->enable_tags == 1
							&& $this->redirect_tags_to_events == 1 && !empty($this->item->tags->itemTags))
						{
							?>
							<div class="tags">
								<i class="fa fa-tags"></i>
								<?php
								foreach ($this->item->tags->itemTags as $key => $tag)
								{
									$url = 'index.php?option=com_jticketing&view=events&layout=default';

									// Get itemid
									$itemId = $this->utilities->getItemId($url);
									$href = Route::_(Uri::base(true) . '/index.php?option=com_jticketing&view=events&layout=default&filter[tags]=' . $tag->tag_id . '&Itemid=' . $itemId);
									?>
									<span class="tag-2 tag-list<?php echo $key; ?>" itemprop="keywords">
										<a href="<?php echo $href; ?>" class="label label-info">
											<?php echo $tag->title;?>
										</a>
									</span>
									<?php
								}
								?>
							</div>
						<?php
						}
						?>
					</div>
				</div>
			</div>
			<!--Event tags if no description-->
		</div>

		<!--Event information tabs - Description, activity, attendees, media-->
		<div class="col-sm-8 col-sm-pull-4">
			<div class="py-15">
				<?php
					$activeTab = '';
					PluginHelper::importPlugin( 'jticketing' );
					$dispatcher = JEventDispatcher::getInstance();
					$results = $dispatcher->trigger( 'onEventContentAfterDisplay', array($this->item));

					if ($this->item->long_description)
					{
						$activeTab = 'tab1';
					}
					elseif ($this->params->get('activity'))
					{
						$activeTab = 'tab2';
					}
					elseif ($this->item->allow_view_attendee == 1 && count($this->item->eventAttendeeInfo) > 0)
					{
						$activeTab = 'tab3';
					}
					elseif (isset($this->item->gallery))
					{
						$activeTab = 'tab4';
					}
					elseif (count($this->extraData) && $this->fieldsIntegration == 'com_tjfields')
					{
						$activeTab = 'tab5';
					}
					elseif ($this->fieldsIntegration == 'com_fields' && property_exists($this->item, "customField"))
					{
						$activeTab = 'tab5';
					}
					elseif (!empty($this->item->venueGallery))
					{
						$activeTab = 'tab6';
					}
					elseif (!empty($results[0]['html']))
					{
						$activeTab = 'tab7';
					}

					echo HTMLHelper::_('bootstrap.startTabSet', 'JTEventTab', array('active' => $activeTab));

					// #tab1 description start
					if ($this->item->long_description)
					{
						echo HTMLHelper::_('bootstrap.addTab', 'JTEventTab', 'tab1', Text::_('COM_JTICKETING_EVENT_TAB_DETAILS')); ?>
						<div class="row ml-5"><?php
							$cleanHtmlLongDescription = InputFilter::getInstance(null, null, 1, 1)->clean($this->item->long_description, 'html');?>
							<?php $long_desc_char = $this->params->get('desc_length', '', 'INT'); ?>
							<div class="long_desc">
									<?php
									if(strlen($cleanHtmlLongDescription) > $long_desc_char )
									{
										echo substr($cleanHtmlLongDescription, 0, $long_desc_char) . ' <a href="javascript:" class="r-more">' . Text::_("COM_JTICKETING_DESCRIPTION_READ_MORE") . '</a>';
									}
									else
									{
										echo $cleanHtmlLongDescription;
									}
									?>
							</div>
							<div class="long_desc_extend no-margin" style="display:none;">
								<?php echo $cleanHtmlLongDescription . ' <a href="javascript:" class="r-less">' . Text::_("COM_JTICKETING_DESCRIPTION_READ_LESS") . '</a>';?>
							</div>
							<!--Event tags-->
							<div class="row">
								<div class="col-xs-12">
									<div class="mt-15">
										<?php
										if ($this->enable_tags == 1 && $this->redirect_tags_to_events == 0 && !empty($this->item->tags->itemTags))
										{
											?>
											<?php $this->item->tagLayout = new JLayoutFile('joomla.content.tags');?>
											<?php echo ($this->item->tagLayout->render($this->item->tags->itemTags));?>
											<?php
										}

										if ($this->enable_tags == 1 && $this->redirect_tags_to_events == 1 && !empty($this->item->tags->itemTags))
										{?>
											<div class="tags">
												<i class="fa fa-tags"></i>
												<?php
												foreach ($this->item->tags->itemTags as $key => $tag)
												{
													$url = 'index.php?option=com_jticketing&view=events&layout=default';

													// Get itemid
													$itemId = JT::utilities()->getItemId($url);
													$href = Route::_(Uri::base(true) . '/index.php?option=com_jticketing&view=events&layout=default&filter[tags]=' . $tag->tag_id . '&Itemid=' . $itemId);
													?>
													<span class="tag-2 tag-list<?php echo $key; ?>" itemprop="keywords">
														<a href="<?php echo $href; ?>" class="label label-info">
															<?php echo $tag->title;?>
														</a>
													</span>
													<?php
												}
												?>
											</div>
										<?php
										}
										?>
									</div>
								</div>
							</div>
						</div>
						<?php
						echo HTMLHelper::_('bootstrap.endTab');
					}
					// #tab1 description end

					// #tab2 activity start
					$activity = $this->params->get('activity');

					if ($activity)
					{
						echo HTMLHelper::_('bootstrap.addTab', 'JTEventTab', 'tab2', strtoupper(Text::_('COM_JTICKETING_EVENT_ACTIVITY')));?>
						<div class="row ml-5">
							<?php echo $this->loadTemplate("activity"); ?>
						</div>
						<?php echo HTMLHelper::_('bootstrap.endTab');
					}
					// #tab2 activity end

					// #tab3 attendee start
					if ($this->item->allow_view_attendee == 1 && count($this->item->eventAttendeeInfo) > 0)
					{
						echo HTMLHelper::_('bootstrap.addTab', 'JTEventTab', 'tab3', strtoupper(Text::_('COM_JTICKETING_EVENT_ATTENDEE')));?>
						<div class="row ml-5">
							<?php echo $this->loadTemplate("attendee"); ?>
						</div>
						<?php echo HTMLHelper::_('bootstrap.endTab');
					}
					// #tab3 attendee end

					// #tab4 event gallery start
					if (isset($this->item->gallery))
					{
						echo HTMLHelper::_('bootstrap.addTab', 'JTEventTab', 'tab4', strtoupper(Text::_('COM_JTICKETING_EVENT_GALLERY')));?>
						<div class="row ml-5">
							<?php echo $this->loadTemplate("gallery"); ?>
						</div>
						<?php echo HTMLHelper::_('bootstrap.endTab');
					}
					// #tab4 event gallery end

					// #tab5 extrafields start
					if (count($this->extraData) && $this->fieldsIntegration == 'com_tjfields')
					{
						echo HTMLHelper::_('bootstrap.addTab', 'JTEventTab', 'tab5', strtoupper(Text::_('COM_JTICKETING_EVENT_ADDITIONAL_INFO')));?>
						<div class="row">
							<div class="col-sm-12">
								<?php
									if ($this->form_extra)
									{
										$count = 0;
										$xmlFieldSets = array();

										foreach ($this->formXml as $k => $xmlFieldSet)
										{
											$xmlFieldSets[$count] = $xmlFieldSet;
											$count++;
										}

										$itemData         = new stdClass();
										$itemData->id     = $this->item->id;
										$itemData->client = 'com_jticketing.event';
										$itemData->created_by = $this->item->created_by;

										// Call the JLayout to render the fields in the details view
										$layout = new FileLayout('event.extrafields', JPATH_ROOT . '/components/com_jticketing');
										echo $layout->render(array('xmlFormObject' => $xmlFieldSets, 'formObject' => $this->form_extra, 'itemData' => $itemData));
									}
								?>
							</div>
						</div>
						<?php echo HTMLHelper::_('bootstrap.endTab');
					}
					elseif ($this->fieldsIntegration == 'com_fields' && property_exists($this->item, "customField"))
					{
						echo HTMLHelper::_('bootstrap.addTab', 'JTEventTab', 'tab5', strtoupper(Text::_('COM_JTICKETING_EVENT_ADDITIONAL_INFO')));?>
						<div class="row ml-5">
							<?php echo $this->loadTemplate("extrafields"); ?>
						</div>
						<?php echo HTMLHelper::_('bootstrap.endTab');
					}
					// #tab5 extrafields end

					// #tab6 venuegallery start
					if (!empty($this->item->venueGallery))
					{
						echo HTMLHelper::_('bootstrap.addTab', 'JTEventTab', 'tab6', strtoupper(Text::_('COM_JTICKETING_VENUE_GALLERY')));?>
						<div class="row ml-5">
							<?php echo $this->loadTemplate("venuegallery"); ?>
						</div>
						<?php echo HTMLHelper::_('bootstrap.endTab');
					}
					// #tab6 venuegallery start

					// #tab7 start
					if (!empty($results[0]['html']))
					{
						echo HTMLHelper::_('bootstrap.addTab', 'JTEventTab', 'tab7', strtoupper($results[0]['tabName']));?>
						<div class="row ml-5">
							<?php echo $results[0]['html']; ?>
						</div>
						<?php echo HTMLHelper::_('bootstrap.endTab');
					}
					// #tab7 start
					echo HTMLHelper::_('bootstrap.endTabSet');?>
			</div>
		</div>

		<div class="col-xs-12 mt-30">
			<!---Map-->
			<?php
				if ($this->item->online_events == '0' && !empty(trim($address)))
				{
					$address = $this->item->venue > 0 ? $this->venueAddress : $this->item->location;
				?>
				<div id="jticketing-event-map" class="responsive-embed responsive-embed-21by9">
					<div id="evnetGoogleMapLocation">
						<iframe width="100%" src="https://www.google.com/maps/embed/v1/place?key=<?php echo $this->params->get('google_map_api_key'); ?>&q=<?php echo $this->escape($address); ?>" allowfullscreen>
						</iframe>
					</div>
				</div>
				<?php
				}
				?>
			<!---Map end-->

			<!--Comment start -->
			<div class="comment mt-20">
			<?php
				// Integration with Jlike
				if (file_exists(JPATH_SITE . '/components/com_jlike/helper.php'))
				{
					$this->showComments = 1;
					$this->showLikeButtons = 0;
					$jLikeUrl = 'index.php?option=com_jticketing&view=event&id=' . (int) $this->item->id;

					echo LayoutHelper::render('event.like_buttons', $this->item, JPATH_SITE . '/' . 'components/com_jticketing/layouts',  array('eventUrl' => $jLikeUrl, 'show_comments' => $this->showComments, 'show_like_buttons' => $this->showLikeButtons));
				}
				?>
			</div>
			<!--Comment end -->
		</div>
		<!--Event information tabs - Description, activity, attendees, media End-->
	</div>
</div><!---tjWrap End-->
<input type="hidden" id="event_id" name="event_id" value="<?php echo $this->item->id;?>"/>
<?php
	$date = Factory::getDate();
	$currentDate = HTMLHelper::date($date, 'Y-m-d H:i:s');
	$startDate = HTMLHelper::date($this->item->startdate, 'Y-m-d H:i:s');
	$endDate = HTMLHelper::date($this->item->enddate, 'Y-m-d H:i:s');
	$guest = Factory::getUser()->id ? 0 : 1;
?>

<script type="text/javascript">
	var event_id = "<?php echo $this->item->id;?>";
	var currentDate ="<?php echo $currentDate;?>";
	var startDate = "<?php echo $startDate;?>";
	var endDate = "<?php echo $endDate;?>";
	var startDateUTC = "<?php echo $this->item->startdate;?>";
	var endDateUTC = "<?php echo $this->item->enddate;?>";
	var guest = "<?php echo $guest?>"
	var onlineEvent = "<?php echo $this->item->online_events;?>";
	jtSite.event.initEventDetailJs();
</script>
