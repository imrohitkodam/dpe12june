<?php
/**
 * @package     corejoomla.administrator
 * @subpackage  com_communitypolls
 *
 * @copyright   Copyright (C) 2009 - 2016 corejoomla.com. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('JPATH_PLATFORM') or die();

JHtml::addIncludePath(JPATH_COMPONENT . '/helpers');
CJFunctions::load_jquery(array('libs'=>array('validate')));
JHtml::_('behavior.caption');

$document 			= JFactory::getDocument();
$params				= $this->params;
$layout 			= $params->get('ui_layout', 'default');
$socialApps 		= $params->get('sharing_services', array());
$show_vote_form 	= $this->item->params->get('show_vote_form');
$access_vote 		= $this->item->params->get('access_vote');
$default_view 		= (!$show_vote_form && $this->item->publish_results) ? 'results' : 'form';

if(count($socialApps) > 0)
{
	$document->addScript('//s7.addthis.com/js/300/addthis_widget.js#async=1');
	$document->addScriptDeclaration('jQuery(document).ready(function($){addthis.init();});');
}

if(in_array($this->item->chart_type, array('sbar', 'gpie')))
{
	$document->addScript('https://www.google.com/jsapi');
	$document->addScriptDeclaration('google.load("visualization", "1", {packages:["corechart"]});');
}

$this->item->params->set('default_view', $default_view);
?>
<style>
.navbar
{
	display :  none !important;
}
</style>
<div id="cj-wrapper" class="poll-details cjpoll-wrapper<?php echo $this->pageclass_sfx?>">

	<?php 
	echo CommunityPollsHelper::renderLayout($layout.'.toolbar', array('params'=>$params, 'state'=>$this->state));
	echo CommunityPollsHelper::renderLayout($layout.'.poll.details', array('data'=>$this));
	echo CommunityPollsHelper::renderLayout($layout.'.poll.messages', array('data'=>$this));
	echo CJFunctions::load_module_position('jcp-below-poll-details');
	
	if( $show_vote_form )
	{
		echo CommunityPollsHelper::renderLayout($layout.'.poll.answers', array('data'=>$this));
	}
	
	if ( $this->item->publish_results )
	{
		echo CommunityPollsHelper::renderLayout($layout.'.poll.results', array('data'=>$this));
	}
	
	echo CJFunctions::load_module_position('jcp-above-vote-buttons');
	
	if($access_vote || ($this->item->publish_results && $show_vote_form))
	{
		?>
		<div class="well well-small poll-action-buttons">
			<div class="error-message"></div>
			<?php if ($this->item->publish_results && $show_vote_form && $this->item->votes > 0):?>
			<button class="btn btn-default btn-view-result" <?php echo $default_view == 'results' ? ' style="display: none"' : '';?>>
				<i class="fa fa-bar-chart-o"></i> <?php echo JText::_('COM_COMMUNITYPOLLS_VIEW_RESULT');?>
			</button>
			<button class="btn btn-default btn-vote-form" <?php echo $default_view == 'form' ? ' style="display: none"' : '';?>>
				<i class="fa fa-th-list"></i> <?php echo JText::_('COM_COMMUNITYPOLLS_VOTE_FORM');?>
			</button>
			<?php endif;?>
			
			<?php if ($access_vote):?>
			<button class="btn btn-primary btn-vote" <?php echo $default_view == 'results' ? ' style="display: none"' : '';?>>
				<i class="fa fa-hand-o-up"></i> <?php echo JText::_('COM_COMMUNITYPOLLS_SUBMIT_VOTE')?>
			</button>
			<?php endif;?>
		</div>
		<?php 
	}
	
	echo CJFunctions::load_module_position('jcp-below-vote-buttons');
	
	if($params->get('show_users_voted', 1) && !empty($this->item->voter_list) && count($this->item->voter_list) > 1)
	{
		echo CommunityPollsHelper::renderLayout($layout.'.poll.voterlist', array('data'=>$this));
	}
	
	$socialApps = $params->get('sharing_services', array());
	if($this->item->anywhere == 1 || count($socialApps) > 0 || $params->get('show_timeline', 1) == 1)
	{
		echo CommunityPollsHelper::renderLayout($layout.'.poll.social', array('data'=>$this));
	}
	
	if(isset($this->item->suggestions) && count($this->item->suggestions) > 0)
	{
		echo CommunityPollsHelper::renderLayout($layout.'.poll.suggestions', array('data'=>$this));
	}
	
	echo CJFunctions::load_module_position('jcp-below-content');
	echo CommunityPollsHelper::renderLayout($layout.'.poll.comments', array('data'=>$this));
	?>
	<input type="hidden" id="cjpageid" value="poll">
	
	<div id="anywhere-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			<h3 id="myModalLabel"><?php echo JText::_('COM_COMMUNITYPOLLS_POLLS_ANYWHERE_TITLE');?></h3>
		</div>
		<div class="modal-body"></div>
		<div class="modal-footer">
			<button class="btn" data-dismiss="modal" aria-hidden="true"><?php echo JText::_('COM_COMMUNITYPOLLS_CLOSE');?></button>
		</div>
	</div>
	
	<div style="display: none;">
		<span id="legend_position" class="legend_position">right</span>
	</div>
</div>
