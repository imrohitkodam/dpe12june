<?php
/**
 * @package    TJ-UCM
 *
 * @author     TechJoomla <extensions@techjoomla.com>
 * @copyright  Copyright (c) 2009-2019 TechJoomla. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die('Restricted access');
use Joomla\CMS\Factory;
use Joomla\CMS\Table\Table;
use Joomla\CMS\Router\Route;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\CMS\Layout\FileLayout;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Helper\TagsHelper;
use Joomla\CMS\Component\ComponentHelper;


if (!key_exists('formObject', $displayData) || !key_exists('xmlFormObject', $displayData))
{
	return;
}

// DPE - Hack  - Start
JLoader::import("/components/com_dpe/includes/dpe", JPATH_SITE);
$params = DPE::config();
$dateFomat = (String) $params->get('dateFormat');
// DPE - Hack  - End

$app = Factory::getApplication();
$user = Factory::getUser();
 $params     			   = ComponentHelper::getParams('com_multiagency');
 $orgAdminRoleId           = (int) $params->get('multiagency_school_admin_group', '0', 'INT');
 $orgAdminRoleId 		   = in_array($orgAdminRoleId, $user->groups);

// Layout for field types
$fieldLayout = array();
$fieldLayout['File'] = $fieldLayout['Image'] = $fieldLayout['Captureimage'] = "file";
$fieldLayout['Checkbox'] = "checkbox";
$fieldLayout['Color'] = "color";
$fieldLayout['multi_select'] = $fieldLayout['single_select'] = $fieldLayout['Radio'] = $fieldLayout['List'] = $fieldLayout['tjlist'] = "list";
$fieldLayout['Itemcategory'] = "itemcategory";
$fieldLayout['Video'] = $fieldLayout['Audio'] = $fieldLayout['Url'] = "link";
$fieldLayout['Calendar'] = "calendar";
$fieldLayout['Cluster'] = "cluster";
$fieldLayout['Related'] = $fieldLayout['SQL'] = "sql";
$fieldLayout['Subform'] = "subform";
$fieldLayout['Ownership'] = "ownership";
$fieldLayout['Editor'] = "editor";
$fieldLayout['Assignee'] = "assignee";
$allowedTags = '<a><strong><br>';


// Load the tj-fields helper
JLoader::import('components.com_tjfields.helpers.tjfields', JPATH_SITE);
$TjfieldsHelper = new TjfieldsHelper;

// Get JLayout data
$xmlFormObject = $displayData['xmlFormObject'];
$formObject = $displayData['formObject'];
$itemData = $displayData['itemData'];
$isSubForm = isset($displayData['isSubForm']) ? $displayData['isSubForm'] : '';
$data = $TjfieldsHelper->FetchDatavalue(array('content_id' => $itemData->id, 'client' => $itemData->client));

// Define the classes for subform and normal form rendering
$controlGroupDivClass = ($isSubForm) ? 'col-xs-12' : 'col-xs-12 col-md-6';
$labelDivClass = ($isSubForm) ? 'col-xs-6' : 'col-xs-4';
$controlDivClass = ($isSubForm) ? 'col-xs-6' : 'col-xs-8';

// Get Field table
Table::addIncludePath(JPATH_ROOT . '/administrator/components/com_tjfields/tables');
$tjFieldsFieldTable = Table::getInstance('field', 'TjfieldsTable');

$fieldSets = $formObject->getFieldsets();
$count = 0;

$tjUcmFrontendHelper = new TjucmHelpersTjucm;

$link = 'index.php?option=com_tjucm&view=items&client=' . $this->client;
$itemId = $tjUcmFrontendHelper->getItemId($link);

?>
<div class="form-validate mt-30">
	<div id="backBtn" class="">
		<a class="fs-16 font-600 cursor-pointer" href="<?php echo Route::_($link . '&Itemid=' . $itemId); ?>">
			<i class="fa fa-arrow-left mr-10" aria-hidden="true"></i>Back
		</a>
		<?php

// if (($user->authorise('core.type.edititem', 'com_tjucm.type.' . $this->ucmTypeId)) || ($user->authorise('core.type.editownitem', 'com_tjucm.type.' . $this->ucmTypeId) && JFactory::getUser()->id == $this->item->created_by))
		$redirectURL = Route::_('index.php?option=com_tjucm&task=itemform.edit&id=' . $itemData->id. '&client=' . $itemData->client, false);
		if (Factory::getUser()->id == $itemData->created_by || empty($itemData->created_by))
		{
			
		?>
		<a class="px-25 ml-10 pull-right edit-record" href="<?php echo $redirectURL; ?>"><i class="fa fa-edit mr-10"></i><?php echo Text::_("COM_TJUCM_EDIT_ITEM"); ?></a>

		<?php
	}
	else if(!$orgAdminRoleId){
		
		
		?>
				<a class="px-25 ml-10 pull-right edit-record" href="<?php echo $redirectURL; ?>"><i class="fa fa-edit mr-10"></i><?php echo Text::_("COM_TJUCM_EDIT_ITEM"); ?></a>

		<?php
		
		}?>
</div>

<!--Create Tabs for Details View -->
<ul class="nav nav-tabs detail-view-tabs">
	<?php
	$fieldSetsCnt = 1;
	foreach ($fieldSets as $fieldset)
	{
		?>
		<li class="<?php echo ($fieldSetsCnt ==1) ? 'active' : ''  ?> tabItem">
			<a data-toggle="tab" href="#<?php echo str_replace(' ', '', $fieldset->name); ?>">
				<?php echo $fieldset->name; ?>
			</a>
		</li>
		<?php
		$fieldSetsCnt++;
	}
	?>
</ul>

<div class="tab-content">

	<?php
	$fieldSetsCnt = 1;

// Call the model 
	BaseDatabaseModel::addIncludePath(JPATH_SITE . '/components/com_tjfields/models');
	$fieldsModelForFeedback = BaseDatabaseModel::getInstance('Fields', 'TjfieldsModel');



// Iterate through the normal form fieldsets and display each one
	foreach ($fieldSets as $fieldset)
	{
		$xmlFieldSet = $xmlFormObject[$count];
		$count++;
		$fieldCount = 0;
		?>
		<div id="<?php echo str_replace(' ', '', $fieldset->name); ?>" class="tab-pane fade <?php echo ($fieldSetsCnt ==1) ? 'in active' : ''  ?>">

			<div class="tjucm-wrapper">
				<div class="row">
					<?php   

					$fieldArray = array();

					foreach ($formObject->getFieldset($fieldset->name) as $field)
					{ 

						if (!empty($field->getAttribute('tags')))
						{
							$temp     = new TagsHelper;
							$tagnames = $temp->getTagNames(array(
								$field->getAttribute('tags')
							));

							if (array_key_exists($fieldsArray, (array) $tagnames[0])) {
								$fieldArray[$tagnames[0]][] = $field;
							} else {
								$fieldArray[$tagnames[0]][] = $field;
							}
						}
						else
						{

							$fieldArray[] = $field;
						}


					}
					
					foreach ($fieldArray as $key => $field)
					{

				if (is_array($field))
				{?>
				<div class="col-12 accordDetail">
					<div class="row">
						<div class="col-12">
							<span class="accordspan"><?php echo  ucwords(str_replace('_', ' ', $key));?></span>
						</div>


						<?php foreach($field as $k => $fieldTags)
						{ 
							// No need to show tooltip/description for field on details view
							$fieldTags->description = '';

							// Get the field data by field name to check the field type

							$tjFieldsFieldTable->load(array('name' => $fieldTags->__get("fieldname")));
							$canView = false;

							if ($user->authorise('core.field.viewfieldvalue', 'com_tjfields.group.' . $tjFieldsFieldTable->group_id))
							{
								$canView = $user->authorise('core.field.viewfieldvalue', 'com_tjfields.field.' . $tjFieldsFieldTable->id);
							}

							if ($canView || ($itemData->created_by == $user->id))
							{
								// Get xml for the field
								$xmlField = $xmlFieldSet->field[$fieldCount];
								$fieldCount++;

								if ($fieldTags->hidden)
								{
									echo $fieldTags->input;
									continue;
								}
								if ($fieldTags->type == 'Ucmsubform')
								{
									?>
									<div class="col-xs-12">
									<!-- <div class="form-fieldset-area py-10">
									<div class="form-horizontal"> -->

										<div class="w-100 font-bold mb-10"><?php echo $fieldTags->getAttribute('label'); ?>:</div>
										<div class="">
											<?php
											$count = 0;
											$ucmSubFormXmlFieldSets = array();

										// Call to extra fields
											JLoader::import('components.com_tjucm.models.item', JPATH_SITE);
											$tjucmItemModel = BaseDatabaseModel::getInstance('Item', 'TjucmModel');

										// Get Subform field data
											$formData = $TjfieldsHelper->getFieldData($fieldTags->getAttribute('name'));
											$ucmSubFormFieldValue = json_decode($formObject->getvalue($fieldTags->getAttribute('name')));

											$ucmSubFormFieldParams = json_decode($formData->params);
											$ucmSubFormFormSource = explode('/', $ucmSubFormFieldParams->formsource);
											$ucmSubFormClient = $ucmSubFormFormSource[1] . '.' . str_replace('form_extra.xml', '', $ucmSubFormFormSource[4]);
											$view = explode('.', $ucmSubFormClient);

											if (!empty($ucmSubFormFieldValue))
											{ 
												foreach ($ucmSubFormFieldValue as $ucmSubFormData)
												{  

													$contentIdFieldname = str_replace('.', '_', $ucmSubFormClient) . '_contentid';

													$ucmSubformFormObject = $tjucmItemModel->getFormExtra(
														array(
															"clientComponent" => 'com_tjucm',
															"client" => $ucmSubFormClient,
															"view" => $view[1],
															"layout" => 'default',
															"content_id" => $ucmSubFormData->$contentIdFieldname)
													);

													$ucmSubFormFormXml = simplexml_load_file($fieldTags->formsource);

													$ucmSubFormCount = 0;

													foreach ($ucmSubFormFormXml as $ucmSubFormXmlFieldSet)
													{
														$ucmSubFormXmlFieldSets[$ucmSubFormCount] = $ucmSubFormXmlFieldSet;
														$ucmSubFormCount++;
													}

													$ucmSubFormRecordData = $tjucmItemModel->getData($ucmSubFormData->$contentIdFieldname);

												// Call the JLayout recursively to render fields of ucmsubform
													$layout = new FileLayout('ucm-field', JPATH_ROOT . '/templates/shaper_helix3/html/layouts/com_tjucm/detail');
													echo $layout->render(array('xmlFormObject' => $ucmSubFormXmlFieldSets, 'formObject' => $ucmSubformFormObject, 'itemData' => $ucmSubFormRecordData, 'isSubForm' => 1));
												//echo "<hr>";

													$tjFieldsFieldTable->load(array('name' => $ucmSubFormClient));


												}
											}
											?>
										</div>
									</div>

									<?php
								}elseif ($fieldTags->type == 'Calendar')
								{
									?>
									<div class="col-md-4 col-sm-6 col-12 pallavi1">
										<div class="form-fieldset-area py-10">
											<div class="form-horizontal">
												<div class="form-group">
											<div class="field-label"><?php echo $fieldTags->getAttribute('label'); ?></div>
											<div class="field-data">
													<?php
										// DPE - Hack  - Start

													$dateFomat = (String) $params->get('dateFormat');

													if ($fieldTags->showtime != 'false')
													{
														$dateFomat = (String) $params->get('dateTimeFormat');
													}
												// DPE - Hack  - End
													echo $output = HTMLHelper::date($fieldTags->value, $dateFomat);
													?>
												</div>
											</div>
										</div>
									</div>
									</div>
									<?php
								}

							else
							{
								$layoutToUse = (array_key_exists($fieldTags->type, $fieldLayout)) ? $fieldLayout[$fieldTags->type] : 'field';
								if ($field->type == 'Freetext')
								{
									?>
									<div class="col-12">
									<?php 
								}else
								{?>
									<div class="col-md-4 col-sm-6 col-12">
									<?php 
								}?>
								<div class="form-fieldset-area py-10">
									<div class="form-horizontal">
										<div class="form-group">
											<?php 
											if ($fieldTags->type == 'Freetext')
												{?>

													<div class="field-label"><?php echo html_entity_decode($fieldTags->getAttribute('freetext')); ?></div>
												<?php }else{ ?>
													<div class="field-label"><?php echo $fieldTags->getAttribute('label'); ?></div>
												<?php } ?>
												<div class="field-data">
													<?php
													$valueFound = 0;

													foreach ($data as $fieldData)
													{
														if ($fieldTags->getAttribute('name') == $fieldData->name)
														{
															$valueFound = 1;
															break;
														}
													}

													if (empty($valueFound))
													{
														$fieldTags->setValue('');
													}


													if ($fieldTags->type == 'Tjfile' || $fieldTags->type == 'Captureimage')
													{
														$layout = new FileLayout('file', JPATH_ROOT . '/templates/shaper_helix3/html/layouts/com_tjfields/fields');
													}
													else
													{
														$layout = new FileLayout($layoutToUse, JPATH_ROOT . '/components/com_tjfields/layouts/fields');
													}



													$output = $layout->render(array('fieldXml' => $xmlField, 'field' => $fieldTags));
														

													// To align text, textarea, textareacounter, editor and tjlist fields properly
													if ($fieldTags->type == 'Textarea'|| $fieldTags->type == 'Textareacounter'|| $fieldTags->type == 'Text' || $fieldTags->type == 'Editor' || $fieldTags->type == 'tjlist')
													{
														?>
														<div class="tj-wordwrap">
															<?php echo $output; 

															if ($tjFieldsFieldTable->showFeedback)
															{  
																if (is_array($fieldTags->value))
																	{ ?>
																		<p class='feedbackDetailColor'> 
																			<?php foreach($fieldTags->value as $values)
																			{ 
																				$fieldFeedbackValue = $fieldsModelForFeedback->getFieldValueByFieldValue($tjFieldsFieldTable->id, $values);

																				if ($fieldFeedbackValue[0]->feedback)
																				{
																					echo "<br> <span>". Strip_tags($fieldFeedbackValue[0]->feedback,$allowedTags) . '</span>';
																				}

																			}
																			?>
																		</p>
																		<?php
																	}
																	else
																	{ 
																		$fieldFeedbackValue = $fieldsModelForFeedback->getFieldValueByFieldValue($tjFieldsFieldTable->id, $fieldTags->value);

																		if ($fieldFeedbackValue[0]->feedback)
																		{
																			echo "<br><p class='feedbackDetailColor'> <br>  <span>". Strip_tags($fieldFeedbackValue[0]->feedback,$allowedTags) . '</span>  </p>';
																		}
																	}
																}

																?>
															</div>
															<?php
														}
												// DPE Hack can go in core
														elseif($fieldTags->type == 'numericcalculation')
														{
															$colorcombination = json_decode($fieldTags->getAttribute('colorcombination'));

															foreach($colorcombination as $key => $colors)
															{										
																if (($output >= $colors->min) && ($output <= $colors->max) )
																{
																	echo "<p class='numericcalculation' style='color:".$colors->color."'>".$colors->value."</p>";
																}
															}
														}
														else
														{
															echo $output;

															if ($tjFieldsFieldTable->showFeedback)
															{  
																if (is_array($fieldTags->value))
																	{ ?>
																		<p class='feedbackDetailColor'> 
																			<?php foreach($fieldTags->value as $values)
																			{ 
																				$fieldFeedbackValue = $fieldsModelForFeedback->getFieldValueByFieldValue($tjFieldsFieldTable->id, $values);

																				if ($fieldFeedbackValue[0]->feedback)
																				{
																					echo "<br> <span>". Strip_tags($fieldFeedbackValue[0]->feedback,$allowedTags) . '</span>';
																				}

																			}
																			?>
																		</p>
																		<?php
																	}
																	else
																	{ 
																		$fieldFeedbackValue = $fieldsModelForFeedback->getFieldValueByFieldValue($tjFieldsFieldTable->id, $fieldTags->value);

																		if ($fieldFeedbackValue[0]->feedback)
																		{
																			echo "<br><p class='feedbackDetailColor'>  <br>  <span>". Strip_tags($fieldFeedbackValue[0]->feedback,$allowedTags) . '</span>  </p>';
																		}
																	}
																}
															}
															?>
														</div>
													</div>
												</div>
											</div>
										</div>
											
										<?php

									}

								}?>
							
						
							<?php 

						}?>
					</div>
					</div>
					<?php
				}
					else
					{
						//echo"<br>";
						
						// No need to show tooltip/description for field on details view
									$field->description = '';

						// Get the field data by field name to check the field type
						$tjFieldsFieldTable->load(array('name' => $field->__get("fieldname")));
						$canView = false;

						if ($user->authorise('core.field.viewfieldvalue', 'com_tjfields.group.' . $tjFieldsFieldTable->group_id))
						{
							$canView = $user->authorise('core.field.viewfieldvalue', 'com_tjfields.field.' . $tjFieldsFieldTable->id);
						}

						if ($canView || ($itemData->created_by == $user->id))
						{
				           // Get xml for the field
							$xmlField = $xmlFieldSet->field[$fieldCount];
							$fieldCount++;

							if ($field->hidden)
							{
								echo $field->input;
								continue;
							}

							if ($field->type == 'Ucmsubform')
							{
								?>
								<div class="col-xs-12">
						<!-- <div class="form-fieldset-area py-10">
						<div class="form-horizontal"> -->

							<div class="w-100 font-bold mb-10"><?php echo $field->getAttribute('label'); ?>:</div>
							<div class="">
								<?php
								$count = 0;
								$ucmSubFormXmlFieldSets = array();

							// Call to extra fields
								JLoader::import('components.com_tjucm.models.item', JPATH_SITE);
								$tjucmItemModel = BaseDatabaseModel::getInstance('Item', 'TjucmModel');

							// Get Subform field data
								$formData = $TjfieldsHelper->getFieldData($field->getAttribute('name'));
								$ucmSubFormFieldValue = json_decode($formObject->getvalue($field->getAttribute('name')));

								$ucmSubFormFieldParams = json_decode($formData->params);
								$ucmSubFormFormSource = explode('/', $ucmSubFormFieldParams->formsource);
								$ucmSubFormClient = $ucmSubFormFormSource[1] . '.' . str_replace('form_extra.xml', '', $ucmSubFormFormSource[4]);
								$view = explode('.', $ucmSubFormClient);

								if (!empty($ucmSubFormFieldValue))
								{ 
									foreach ($ucmSubFormFieldValue as $ucmSubFormData)
									{  

										$contentIdFieldname = str_replace('.', '_', $ucmSubFormClient) . '_contentid';

										$ucmSubformFormObject = $tjucmItemModel->getFormExtra(
											array(
												"clientComponent" => 'com_tjucm',
												"client" => $ucmSubFormClient,
												"view" => $view[1],
												"layout" => 'default',
												"content_id" => $ucmSubFormData->$contentIdFieldname)
										);

										$ucmSubFormFormXml = simplexml_load_file($field->formsource);

										$ucmSubFormCount = 0;

										foreach ($ucmSubFormFormXml as $ucmSubFormXmlFieldSet)
										{
											$ucmSubFormXmlFieldSets[$ucmSubFormCount] = $ucmSubFormXmlFieldSet;
											$ucmSubFormCount++;
										}

										$ucmSubFormRecordData = $tjucmItemModel->getData($ucmSubFormData->$contentIdFieldname);

									// Call the JLayout recursively to render fields of ucmsubform
										$layout = new FileLayout('ucm-field', JPATH_ROOT . '/templates/shaper_helix3/html/layouts/com_tjucm/detail');
										echo $layout->render(array('xmlFormObject' => $ucmSubFormXmlFieldSets, 'formObject' => $ucmSubformFormObject, 'itemData' => $ucmSubFormRecordData, 'isSubForm' => 1));
									//echo "<hr>";

										$tjFieldsFieldTable->load(array('name' => $ucmSubFormClient));


									}
								}
								?>
							</div>
						</div>

						<?php
					}
					elseif ($field->type == 'Calendar')
					{
						?>
						<div class="col-md-4 col-sm-6 col-12">
							<div class="form-fieldset-area py-10">
								<div class="form-horizontal">
									<div class="form-group">
										<div class="field-label"><?php echo $field->getAttribute('label'); ?></div>
										<div class="field-data">
											<?php
								// DPE - Hack  - Start

											$dateFomat = (String) $params->get('dateFormat');

											if ($field->showtime != 'false')
											{
												$dateFomat = (String) $params->get('dateTimeFormat');
											}
										// DPE - Hack  - End
											echo $output = HTMLHelper::date($field->value, $dateFomat);
											?>
										</div>
									</div>
								</div>
							</div>
						</div>
						<?php
					}
					else
					{
						$layoutToUse = (array_key_exists($field->type, $fieldLayout)) ? $fieldLayout[$field->type] : 'field';
						if ($field->type == 'Freetext')
											{
						?>
						<div class="col-12">
						<?php }else{?>
						<div class="col-md-4 col-sm-6 col-12">
						<?php }?>
							<div class="form-fieldset-area py-10">
								<div class="form-horizontal">
									<div class="form-group">
										<?php 
										if ($field->type == 'Freetext')
											{?>

												<div class="field-label"><?php echo html_entity_decode($field->getAttribute('freetext')); ?></div>
											<?php }else{ ?>
												<div class="field-label"><?php echo $field->getAttribute('label'); ?></div>
											<?php } ?>
											<div class="field-data">
												<?php
												$valueFound = 0;

												foreach ($data as $fieldData)
												{
													if ($field->getAttribute('name') == $fieldData->name)
													{
														$valueFound = 1;
														break;
													}
												}

												if (empty($valueFound))
												{
													$field->setValue('');
												}


												if ($field->type == 'Tjfile' || $field->type == 'Captureimage')
												{
													$layout = new FileLayout('file', JPATH_ROOT . '/templates/shaper_helix3/html/layouts/com_tjfields/fields');
												}
												else
												{
													$layout = new FileLayout($layoutToUse, JPATH_ROOT . '/components/com_tjfields/layouts/fields');
												}

												$output = $layout->render(array('fieldXml' => $xmlField, 'field' => $field));


							// To align text, textarea, textareacounter, editor and tjlist fields properly
												if ($field->type == 'Textarea'|| $field->type == 'Textareacounter'|| $field->type == 'Text' || $field->type == 'Editor' || $field->type == 'tjlist')
												{
													?>
													<div class="tj-wordwrap">
														<?php echo $output; 

														if ($tjFieldsFieldTable->showFeedback)
														{  
															if (is_array($field->value))
																{ ?>
																	<p class='feedbackDetailColor'> 
																		<?php foreach($field->value as $values)
																		{ 
																			$fieldFeedbackValue = $fieldsModelForFeedback->getFieldValueByFieldValue($tjFieldsFieldTable->id, $values);

																			if ($fieldFeedbackValue[0]->feedback)
																			{
																				echo "<br> <span>". Strip_tags($fieldFeedbackValue[0]->feedback,$allowedTags) . '</span>';
																			}

																		}
																		?>
																	</p>
																	<?php
																}
																else
																{ 
																	$fieldFeedbackValue = $fieldsModelForFeedback->getFieldValueByFieldValue($tjFieldsFieldTable->id, $field->value);

																	if ($fieldFeedbackValue[0]->feedback)
																	{
																		echo "<br><p class='feedbackDetailColor'> <br>  <span>". Strip_tags($fieldFeedbackValue[0]->feedback,$allowedTags) . '</span>  </p>';
																	}
																}
															}

															?>
														</div>
														<?php
													}
							                   // DPE Hack can go in core
													elseif($field->type == 'numericcalculation')
													{
														$colorcombination = json_decode($field->getAttribute('colorcombination'));

														foreach($colorcombination as $key => $colors)
														{										
															if (($output >= $colors->min) && ($output <= $colors->max) )
															{
																echo "<p class='numericcalculation' style='color:".$colors->color."'>".$colors->value."</p>";
															}
														}
													}
													else
													{
														echo $output;

														if ($tjFieldsFieldTable->showFeedback)
														{  
															if (is_array($field->value))
																{ ?>
																	<p class='feedbackDetailColor'> 
																		<?php foreach($field->value as $values)
																		{ 
																			$fieldFeedbackValue = $fieldsModelForFeedback->getFieldValueByFieldValue($tjFieldsFieldTable->id, $values);

																			if ($fieldFeedbackValue[0]->feedback)
																			{
																				echo "<br> <span>". Strip_tags($fieldFeedbackValue[0]->feedback,$allowedTags) . '</span>';
																			}

																		}
																		?>
																	</p>
																	<?php
																}
																else
																{ 
																	$fieldFeedbackValue = $fieldsModelForFeedback->getFieldValueByFieldValue($tjFieldsFieldTable->id, $field->value);

																	if ($fieldFeedbackValue[0]->feedback)
																	{
																		echo "<br><p class='feedbackDetailColor'>  <br>  <span>". Strip_tags($fieldFeedbackValue[0]->feedback,$allowedTags) . '</span>  </p>';
																	}
																}
															}
														}
														?>
													</div>
												</div>
											</div>
										</div>
									</div>
									<?php
								}
							}

					}
					?>

			<!-- </div>
			</div>
		</div> -->
		<?php
		} // End of foreach
		?>
	</div>
</div>
<!-- tab-pane Ends Here -->
</div>

<?php
$fieldSetsCnt++;

}

?>
<!-- tab-content Ends Here -->
</div>

<!-- Container Ends Here -->
</div>
<!-- <script>

	function printData()
	{
		jQuery(".tab-pane").addClass("active");
		jQuery(".tab-pane").addClass("in");
		jQuery('#backBtn').hide();
		jQuery("#sp-page-title").hide();
		jQuery(".logo").hide();
		var prtContentData = [];
		var prtContentLable = [];
		var finalPrtContent = [];
		var divId =[];
		var navBar = '';
		var dataprint ='';
		var WinPrint = '';
		WinPrint = window.open('', '', 'left=0,top=0,width=500,height=1200,toolbar=0,scrollbars=0,status=0');
		jQuery(".tab-content").find('.tab-pane').each(function(i, obj) {
			divId[i] = jQuery(this).attr('id');
			navBar = jQuery('a[href*=#'+ divId[i]+']').text();

			prtContentLable[i] = [];
			prtContentData[i] = [];
			jQuery("#"+divId[i]).find('.field-label').each(function(k, obj) {

				prtContentLable[i][k] = '<div class ="col-xs-4" style="word-break: break-word; "><p style="font-weight:700;">'+jQuery(this).text()+'</p><p style="color: #211e1ec9;">'+jQuery(this).next().text()+'</p></div>';	

				prtContentLable[i][k] = prtContentLable[i][k].replace(/,/g , ''); 


			});
			finalPrtContent[i]= '<div class = "row"><h3 class="fs-3" style="page-break-before: always;">'+navBar+'</h3>' + prtContentLable[i] +'</div>';			
		});
			// remove the comma from the div
			for(var i=0; i< finalPrtContent.length; i++)
			{
				finalPrtContent[i] = finalPrtContent[i].replace(/\>,/g, '>');
			}


			dataprint  = '<head><style>.container:before{display: table;content:none;} .container:after{display: table;content:none;} .row:before{display: table;content:none;} .row:after{display: table;content:"";} 				@media print{.fs-3{    background: #22b8f0!important;color: white!important;padding: 10px!important;}}</style></head><body><div class = "container">'+finalPrtContent +"</div></body>";	
			
			WinPrint.document.write('<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous"> <script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"><\/script>' + dataprint);
			WinPrint.document.close();
			WinPrint.focus();
			jQuery('.container-fluid').css('::before');
			setTimeout(() => {
				WinPrint.print();
				WinPrint.close();
				window.location.reload(true)
			},300); 
		}
	</script> -->

<script>
	jQuery('window').ready(function(){

			jQuery('.tabItem').click(function(){

			jQuery('.tabItem').removeClass('active');
		    jQuery(this).addClass('active');
		    
		    var clickedHref = $(this).find('a').attr('href').substring(1);

		    jQuery('.tab-pane').removeClass('in active');
		    jQuery('#' + clickedHref.replace('/', '\\/')).addClass('in active');
		    return false; // Prevent the default link behavior


				})

	})
</script>
