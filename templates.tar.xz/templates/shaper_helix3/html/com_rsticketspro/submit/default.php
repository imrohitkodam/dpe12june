<?php
/**
 * @package    RSTickets! Pro
 *
 * @copyright  (c) 2010 - 2016 RSJoomla!
 * @link       https://www.rsjoomla.com
 * @license    GNU General Public License http://www.gnu.org/licenses/gpl-3.0.en.html
 */

defined('_JEXEC') or die('Restricted access');
use Joomla\CMS\Language\Text;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Form\FormHelper;
use Joomla\Registry\Registry;

use Joomla\CMS\User\User;
use Joomla\CMS\Factory;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\CMS\Component\ComponentHelper;

HTMLHelper::_('behavior.keepalive');
HTMLHelper::_('bootstrap.tooltip');
HTMLHelper::_('formbehavior.chosen', 'select');
HTMLHelper::_('behavior.formvalidator');
HTMLHelper::_('script', 'media/com_dpe/js/rsticket.min.js');
HTMLHelper::_('jquery.token');

JLoader::import('main', JPATH_SITE . '/components/com_dpe/helpers');
DpeMainHelper::getLanguageConstant();

$user = Factory::getUser();
$app  = Factory::getApplication();
$this->agency_id = '';

JText::script("RST_TICKET_SELECT_SCHOOL_ERROR");

// Dont allow Trustee to add ticket
$params                    = ComponentHelper::getParams('com_multiagency');
$groupMultiagecnyTrusteeId = (INT) $params->get('multiagency_trustee_group');

/*
// Validate user login.
if (in_array($groupMultiagecnyTrusteeId, $user->groups))
{
	$app->enqueueMessage(Text::_('JERROR_ALERTNOAUTHOR'), 'warning');
	$link = base64_encode((string) Uri::getInstance());
	$app->redirect(Route::_('index.php?option=com_users&view=login&return=' . $link, false));
}
*/

// Check user is logged-in or not
if (!$user->id)
{
	$app->enqueueMessage(Text::_('RST_CANNOT_SUBMIT_TICKET'), 'warning');
	$link = base64_encode((string) Uri::getInstance());
	$app->redirect(RSTicketsProHelper::route('index.php?option=com_users&view=login&return=' . $link, false));
}
?>

<div class="com-rsticketspro-submit-ticket<?php echo $this->escape($this->params->get('pageclass_sfx')); ?>">
<!--
	<div class="row-fluid">
		<div class="page-header">
			<h2><?php echo $this->escape($this->params->get('page_heading')); ?></h2>
		</div>
	</div>
-->

	<?php
	if ($this->globalMessage)
	{
		?>
	<div class="alert alert-warning"><?php echo $this->globalMessage;?></div>
	<?php
	}

	if ($this->submitMessage)
	{
		?>
	<div class="alert alert-warning"><?php echo $this->submitMessage;?></div>
	<?php
	}
		?>

	<form action="<?php echo Route::_('index.php?option=com_rsticketspro&view=submit'); ?>" method="post" name="adminForm"
	id="adminForm" class="form-validate  col-sm-9 ucm-form-styling" enctype="multipart/form-data">
		<?php
		$this->field->startFieldset();

			// Only staff members with enough permissions Can select existing users from the database
			/* @TO DO Will Remove code after discussion and getting feedback from client
			Code - This code shows super user can add ticket on behalf of other registered users.
			if ($this->canChangeSubmitType)
			{
				// Submit type
				$label = $this->form->getLabel('submit_type');
				$input = $this->form->getInput('submit_type');
				$this->field->showField($label, $input);

				// Email
				$label = $this->form->getLabel('email');
				$input = $this->form->getInput('email');
				$this->field->showField($label, $input, array('id' => 'rst_email_container'));

				// Name
				$label = $this->form->getLabel('name');
				$input = $this->form->getInput('name');
				$this->field->showField($label, $input, array('id' => 'rst_name_container'));

				// Customer
				$label = $this->form->getLabel('customer_id');
				$input = $this->form->getInput('customer_id');
				$this->field->showField($label, $input, array('id' => 'rst_customer_id_container', 'class' => 'clearfix'));
			}
			else*/
			{
				// Email
				$label = $this->form->getLabel('email');

				if ($this->user->get('id'))
				{
					$input = $this->escape($this->user->get('email'));
				}
				else
				{
					$input = $this->form->getInput('email');
				}

				$this->field->showField($label, $input, array('class' => 'clearfix'));

				if (!$this->user->get('id') && (bool) RSTicketsProHelper::getConfig('allow_password_change'))
				{
					$label = $this->form->getLabel('password');
					$input = $this->form->getInput('password');
					$this->field->showField($label, $input);
				}

				// Name
				$label = $this->form->getLabel('name');

				if ($this->user->get('id'))
				{
					$input = $this->escape($this->user->get('name'));
				}
				else
				{
					$input = $this->form->getInput('name');
				}

				$this->field->showField($label, $input, array('class' => 'clearfix'));
			}
			?>
			<div class="control-group">
				<label for="jform_country" class="control-label">
					<?php echo HTMLHelper::tooltip(Text::sprintf('RST_TICKET_SCHOOL_TOOLTIP', Text::_('COM_MULTIAGENCY_ORGANISATION')), Text::sprintf('RST_TICKET_SCHOOL_DESC', Text::_('COM_MULTIAGENCY_ORGANISATION')), '', Text::sprintf('RST_TICKET_SCHOOL_LBL', Text::_('COM_MULTIAGENCY_ORGANISATION')) . ' * '); ?>
				</label>
				<div class="controls">
					<?php
					// To get Agency dropdown list
					FormHelper::addFieldPath(JPATH_ADMINISTRATOR . '/components/com_tjfields/models/fields');
					$agencyList = FormHelper::loadFieldType('cluster', false);
					$this->agencyOptions = $agencyList->getOptionsExternally();
					echo HTMLHelper::_(
						'select.genericlist', $this->agencyOptions,
						'jform[cluster]', 'class="inputbox required" required="required" name="cluster"'  , 'value', 'text'
						);
					?>
				</div>
			</div>
			<div class="control-group">
				<label class="control-label">
					<?php echo HTMLHelper::tooltip(Text::_('RST_TICKET_CC_USERS'), Text::sprintf('RST_TICKET_CC_USERS_DESC', Text::_('COM_MULTIAGENCY_ORGANISATION')), '', Text::_('RST_TICKET_CC_USERS')); ?>
				</label>
				<div class="controls">
					<?php
					// To get Agency dropdown list
					echo HTMLHelper::_(
						'select.genericlist', '',
						'jform[clusterusers][]', 'class="inputbox" name="clusterusers" multiple="true"'  , 'value', 'text'
						);
					?>
					<i id="loader"></i>
				</div>
			</div>
			<?php
			// Department

			// Get plugin 'ticket' of type 'rsticketspro'
			$plugin = PluginHelper::getPlugin('rsticketspro', 'ticket');

			// Check if plugin is enabled
			if ($plugin)
			{
				// Get plugin params
				$pluginParams = new Registry($plugin->params);
				$defaultDptId = $pluginParams->get('select_department');
			}

			$label = $this->form->getLabel('department_id');
			$input = $this->form->getInput('department_id', null, $defaultDptId);
			$this->field->showField($label, $input, array('class' => 'hide'));

			// Append the custom fields after the department
			foreach ($this->customFields as $customField)
			{
				if (in_array($customField->type, array('freetext','radio','checkbox')))
				{
					$input = '<div class="rst_editor">';

					if (in_array($customField->type, array('radio','checkbox')))
					{
						$input .= '<div class="rst_custom_field">';
						$input .= $customField->input;
					}

					if (in_array($customField->type, array('radio','checkbox')))
					{
						$input .= '</div>';
						$input .= '</div>';
					}
				}
				else
				{
					$input = $customField->input;
				}

				$this->field->showField(
				$customField->label, $input, array('class' => 'rst_field_container clearfix rst_field_container_' . $customField->department_id)
				);
			}

			// Subject
			$label = $this->form->getLabel('subject');
			$input = $this->form->getInput('subject');
			$this->field->showField($label, $input);

			// Message
			$label = $this->form->getLabel('message');
			$input = $this->form->getInput('message');
			$this->field->showField($label, '<div class="rst_editor">' . $input . '</div>');

			// Priority
			$label = $this->form->getLabel('priority_id');
			$input = $this->form->getInput('priority_id');
			$this->field->showField($label, $input);

			// Prepend the upload message
			$label = '';
			$input = '';
			?>
			<div class='text-center'>
				<?php	$this->field->showField($label, $input, array('id' => 'rst_files_message_container'));?>
			</div>
			<?php
			// Files
			$label = $this->form->getLabel('files');
			$input = $this->form->getInput('files');
			$this->field->showField($label, $input, array('id' => 'rst_files_container'));

			// Captcha
			if ($this->hasCaptcha)
			{
				$label = $this->form->getLabel('captcha');
				$input = $this->form->getInput('captcha');
				$this->field->showField($label, $input);
			}

			// DPE - Hack for DPE specific - Client don't want conset from the user who has addding a ticket
			$label = $this->form->getLabel('consent');
			$input = $this->form->getInput('consent', array(), '1');
			$this->field->showField($label, $input, array('class' => 'hide'));

			// Submit button
			$label = '';
			$input = '<button type="button" class="btn btn-primary float-end" onclick="Joomla.submitbutton(\'submit.save\');">' . Text::_('RST_SUBMIT') . '</button>';
			$this->field->showField($label, $input, array('class' => 'col-sm-4 text-right pull-right'));
		$this->field->endFieldset();
	?>
		<div>
			<?php echo HTMLHelper::_('form.token'); ?>
			<input type="hidden" name="task" value="" />
		</div>
	</form>
</div>
<script type="text/javascript">

Joomla.submitbutton = function(task) {
    if (task == 'submit.save') {
        var agency = document.getElementById('jformcluster').value;
        if (agency == '') {
            alert(Joomla.Text._('RST_TICKET_SELECT_SCHOOL_ERROR'));
            return false;
        } else {
            Joomla.submitform(task);
        }
    }
}

RSTicketsPro.departments[''] = {
	id: 0,
	priority: '',
	uploads: {
		allowed: false,
		message: '',
		max: 0
	}
};
<?php
	foreach ($this->departments as $department)
	{
		?>
		RSTicketsPro.departments[<?php echo $department->id; ?>] = {
			id: <?php echo $department->id; ?>,
			priority: <?php echo $department->priority_id; ?>,
			uploads: {
				allowed: <?php echo $department->upload ? 'true' : 'false'; ?>,
				message: '<?php echo addslashes($department->upload_message); ?>',
				max: <?php echo $department->upload_files; ?>
			}
		};
<?php
	}?>
RSTicketsPro.changeDepartment();
<?php
	if ($this->canChangeSubmitType)
	{
	?>
		RSTicketsPro.changeSubmitType();
<?php
	}?>
</script>
