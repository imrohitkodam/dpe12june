<?php
/**
 * @package    RSTickets! Pro
 *
 * @copyright  (c) 2010 - 2016 RSJoomla!
 * @link       https://www.rsjoomla.com
 * @license    GNU General Public License http://www.gnu.org/licenses/gpl-3.0.en.html
 */

defined('_JEXEC') or die('Restricted access');
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\CMS\Factory;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;

// Load JavaScript message titles
Text::script('ERROR');
Text::script('WARNING');
Text::script('NOTICE');
Text::script('MESSAGE');
HTMLHelper::_('behavior.formvalidator');
HTMLHelper::_('behavior.keepalive');
$user = Factory::getUser();

// Get School Information
if (!empty($this->ticket->id) && $this->ticket->id != 0)
{
	JLoader::register('DpeModelRsticketspro', JPATH_SITE . '/components/com_dpe/models/rsticketspro.php');
	$dpeModelRsticketspro = BaseDatabaseModel::getInstance('Rsticketspro', 'DpeModel', array('ignore_request' => true));
	$this->ticket->school = $dpeModelRsticketspro->getTicketXrefData($this->ticket->id);

	// Get users by roles

	$clustertable = ClusterFactory::table('Clusters');
	$clustertable->load(array('id' => $this->ticket->school['agency_id']));

	// Get cluster users on edit ticket
	$rsticketModel = DPE::model('rsticket');
	$client = 'com_multiagency';
	$this->clusterUsers = $rsticketModel->getUsersByActions(array('core.adduser'), $client, $clustertable->client_id);
	$staffUsers = $rsticketModel->getUsersByActions(array('core.view.all'), $client, $clustertable->client_id);

	if (!empty($staffUsers))
	{
		$this->clusterUsers = array_merge($this->clusterUsers, $staffUsers, ($publicUsers)?$publicUsers:array());
	}

	// Get dpe admin roles
	if ($user->authorise('core.manageall', 'com_cluster'))
	{
		$dpeAdminUsers = $rsticketModel->getUsersByActions(array('core.create'), 'com_multiagency');
		$this->clusterUsers = array_merge($this->clusterUsers, $dpeAdminUsers);
	}
}

// Get create Ticket list menu
$mainframe          = Factory::getApplication();
$menu               = $mainframe->getMenu();
$ticketListMenuItem = $menu->getItems('link', 'index.php?option=com_dpe&view=rsticketspro', true );
$backLink           = Route::_('index.php?option=com_dpe&view=rsticketspro&filter[agencies]=all&Itemid=' . $ticketListMenuItem->id, false, 0);

// Get Current url for notification manager widget
$extraParams = Uri::getInstance()->toString(array('query'));
$extraParams = str_replace('?', '&', $extraParams);
$urlId = '';
$input = $mainframe->input;

if ($input->getInt('id'))
{
	$urlId = '&id=' . $input->getInt('id');
}

$currentUrl =  'index.php?option=' . $input->get('option') . '&view=' . $input->get('view') . $urlId . $extraParams .'&Itemid=' . $input->get('Itemid');
?>

<script type="text/javascript">
Joomla.submitbutton = function(task)
{
	if (task == 'ticket.cancel' || task == 'ticket.updateinfo' || task == 'ticket.savetimespent' || task == 'ticket.updatefields' || document.formvalidator.isValid(document.getElementById('adminForm')))
	{
		Joomla.submitform(task, document.getElementById('adminForm'));

		if (typeof button != 'undefined' && task == 'ticket.reply')
		{
			button.disabled = true;
		}
	}
	else
	{
		if (typeof button != 'undefined' && task == 'ticket.reply')
		{
			button.disabled = false;
		}

		alert('<?php echo $this->escape(Text::_('COM_RSTICKETSPRO_PLEASE_COMPLETE_ALL_FIELDS'));?>');
	}
}
</script>
<div>
<a class="fs-16 font-600 cursor-pointer" href="<?php echo $backLink;?>"><i class="fa fa-arrow-left mr-10" aria-hidden="true"></i><?php echo Text::_('COM_DPE_BACK_BUTTON');?></a>
</div>
<div> <h2 class="float-right"><?php echo Text::_('COM_RSTICKETSPRO_TICKET_NO') .' '. $this->ticket->id?></h2></div>
<div class="rsTicketDetail" id="rsTicketDetail">
	<?php
	if ($this->params->get('show_page_heading', 1))
	{
		?>
			<h2><?php echo $this->escape($this->ticket->subject); ?></h2>
	<?php
	}

	if ($this->globalMessage)
	{
		?>
		<div class="row-fluid" id="ticket-global-message">
			<div class="alert alert-warning">
				<?php echo $this->globalMessage;?>
			</div>
		</div>
	<?php
	}
	?>

	<form action="<?php echo RSTicketsProHelper::route('index.php?option=com_rsticketspro&view=ticket'); ?>"
	method="post" name="adminForm" id="adminForm" class="form-validate ucm-form-styling create-campaign my-support-view" enctype="multipart/form-data" autocomplete="off">
	<?php
		if ($this->ticketView == 'plain' || $this->isPrint)
		{
			?>
			<div class="row-fluid">
				<div class="span12" id="ticket-left-column">
					<?php echo $this->loadTemplate('messages'); ?>
				</div>
			</div>
			<div class="row-fluid">
				<div class="span12" id="ticket-right-column">
					<?php
					foreach ($this->ticketSections as $layout => $title)
					{
						if ($layout == 'messages')
						{
							continue;
						}

						if (empty($this->ticket->fields) && $layout == 'custom_fields')
						{
							continue;
						}

						// Add the title
						$this->plain->addTitle($title, $layout);
						$content = $this->loadTemplate($layout);

						// Add the content
						$this->plain->addContent($content);
					}

					// Allow plugins to inject content here
					RSTicketsProHelper::trigger('onAfterTicketInformation', array($this->ticket, $this->plain));

					// Render the plain view
					$this->plain->render();
					?>
				</div>
			</div>
		<?php
		}
		elseif ($this->ticketView == 'accordion')
		{
			foreach ($this->ticketSections as $layout => $title)
			{
				if (empty($this->ticket->fields) && $layout == 'custom_fields')
				{
					continue;
				}

				// Add the tab title
				$this->accordion->addTitle($title, $layout);
				$content = $this->loadTemplate($layout);

				// Add the tab content
				$this->accordion->addContent($content);
			}

			// Allow plugins to inject content here
			RSTicketsProHelper::trigger('onAfterTicketInformation', array($this->ticket, $this->accordion));

			// Render tabs
			$this->accordion->render();
		}
		else
		{
			foreach ($this->ticketSections as $layout => $title)
			{
				if (empty($this->ticket->fields) && $layout == 'custom_fields')
				{
					continue;
				}

				// Add the tab title
				$this->tabs->addTitle($title, $layout);
				$content = $this->loadTemplate($layout);

				// Add the tab content
				$this->tabs->addContent($content);
			}

			// Allow plugins to inject content here
			RSTicketsProHelper::trigger('onAfterTicketInformation', array($this->ticket, $this->tabs));

			// Render tabs
			$this->tabs->render();
		}
		?>
		<div>
			<?php echo HTMLHelper::_('form.token'); ?>
			<input type="hidden" name="id" value="<?php echo $this->ticket->id; ?>" />
			<input type="hidden" name="cid" value="<?php echo $this->ticket->id; ?>" />
			<input type="hidden" name="task" value="" />
			<input type="hidden" name="option" value="com_rsticketspro" />

			<!-- DPE Hack start to add hidden fields to create content for notification manager -->
			<input type="hidden" name="url" id="url" value="<?php echo $currentUrl;?>"/>
			<input type="hidden" name="element" id="element" value="com_rsticket.ticket"/>
			<input type="hidden" name="element_id" id="element_id" value="<?php echo $this->ticket->id;?>"/>
			<input type="hidden" name="cluster_id" id="cluster_id" value="<?php echo $this->ticket->school['agency_id'];?>"/>
			<!-- DPE Hack end -->
		</div>
	</form>
</div>
