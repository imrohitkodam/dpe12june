<?php
use Joomla\CMS\Factory;
?>

<ul class="latestnews">
<?php

// Get acym archive list menu id
$app = Factory::getApplication();
$menu = $app->getMenu();
$items = $menu->getItems('link', 'index.php?option=com_acym&view=archive&layout=listing');

foreach ($data['newsletters'] as $item)
{
	$archiveURL = acym_frontendLink('archive&task=view&id=' . $item->id . '&Itemid=' . $items[0]->id);
 ?>
	<li class="latestnews">
		<a class="latestnews" href="<?php echo $archiveURL; ?>"><?php echo $item->subject; ?></a>
	</li>
<?php
} ?>
</ul>
