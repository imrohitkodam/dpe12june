<?php
/**
 * @version    SVN: <svn_id>
 * @package    Com_Tjucm
 * @author     Techjoomla <extensions@techjoomla.com>
 * @copyright  Copyright (c) 2009-2018 TechJoomla. All rights reserved.
 * @license    GNU General Public License version 2 or later.
 */

// No direct access
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Session\Session;
use Joomla\CMS\Form\FormHelper;
use Joomla\CMS\Table\Table;

HTMLHelper::addIncludePath(JPATH_COMPONENT . '/helpers/html');
HTMLHelper::_('bootstrap.tooltip');
HTMLHelper::_('behavior.multiselect');
HTMLHelper::_('formbehavior.chosen', 'select');

$user = Factory::getUser();
$userId = $user->get('id');
$tjUcmFrontendHelper = new TjucmHelpersTjucm;
$listOrder = $this->state->get('list.ordering');
$listDirn = $this->state->get('list.direction');
$appendUrl = '';
$csrf = "&" . Session::getFormToken() . '=1';

if (!empty($this->created_by))
{
	$appendUrl .= "&created_by=" . $this->created_by;
}

if (!empty($this->client))
{
	$appendUrl .= "&client=" . $this->client;
}

$tmpListColumn = $this->listcolumn;
reset($tmpListColumn);
$firstListColumn = key($tmpListColumn);

$link = 'index.php?option=com_tjucm&view=items' . $appendUrl;
$itemId = $tjUcmFrontendHelper->getItemId($link);

$clusterFieldId = $ownershipFieldId = '';
Table::addIncludePath(JPATH_ROOT . '/administrator/components/com_tjfields/tables');
$fieldInstance = Table::getInstance('Field', 'TjfieldsTable', array('dbo', $db));
$fieldInstance->load(array('client' => $this->client, 'type' => 'cluster', 'state' => 1));

if ($fieldInstance->id)
{
	$clusterFieldId = $fieldInstance->id;
}

$fieldInstance->load(array('client' => $this->client, 'type' => 'ownership', 'state' => 1));

if ($fieldInstance->id)
{
	$ownershipFieldId = $fieldInstance->id;
}
?>
<form action="<?php echo Route::_($link . '&Itemid=' . $itemId); ?>" method="post" name="adminForm" id="adminForm">
<div class="dp-search-filter">
	<div id="filter-progress-bar" class="col-sm-12 col-md-4 pl-0">
						<div class="input-group">
								<input type="text" class="w-100" name="filter_search" id="filter_search"
								title="<?php echo empty($firstListColumn) ? Text::_('JSEARCH_FILTER') : Text::sprintf('COM_TJUCM_ITEMS_SEARCH_TITLE', $this->listcolumn[$firstListColumn]); ?>"
								value="<?php echo $this->escape($this->state->get('filter.search')); ?>"
								placeholder="<?php echo Text::_('JSEARCH_FILTER'); ?>"/>
								<span class="input-group-btn">
									<button class="btn btn-default" type="submit" title="<?php echo Text::_('JSEARCH_FILTER_SUBMIT'); ?>"><span class="icon-search"></span></button>
									<button class="btn btn-basic qtc-hasTooltip br-4 mx-10" id="clear-search-button" onclick="document.getElementById('filter_search').value='';this.form.submit();" type="button" title="<?php echo Text::_('JSEARCH_FILTER_CLEAR'); ?>">Clear</button>
								</span>
						</div>
			</div>
		<?php
		// Check if com_cluster component is installed
		if (ComponentHelper::getComponent('com_cluster', true)->enabled)
		{
			FormHelper::addFieldPath(JPATH_ADMINISTRATOR . '/components/com_tjfields/models/fields/');
			$cluster           = FormHelper::loadFieldType('cluster', false);
			$this->clusterList = $cluster->getOptionsExternally();
			if ($this->allowedToAdd)
			{
				?>
				<div class="col-md-8 pr-0 text-right">
					<a href="<?php echo Route::_('index.php?option=com_tjucm&task=itemform.edit' . $appendUrl, false); ?>" class="btn btn-primary btn-small pull-right">
						<i class="icon-plus"></i><?php echo Text::_('COM_TJUCM_ADD_ITEM'); ?>
					</a>
				<?php
			}?>
			<div class="btn-group hidden-xs md-w-300px text-left">
				<?php
					echo HTMLHelper::_('select.genericlist', $this->clusterList, "cluster", 'class="input-medium" size="1" onchange="this.form.submit();"', "value", "text", $this->state->get('filter.cluster_id', '', 'INT'));
				?>
			</div>
			<?php
		}?>
			<div class="btn-group hidden-xs mx-10">
			<?php echo $this->pagination->getLimitBox(); ?>
		</div>
	</div>
	</div>
	</div>
	<div class="clearfix"></div>
	<div class="table-responsive mt-20px">
		<table class="table table-striped" id="itemList">
			<?php
			if (!empty($this->showList))
			{
				if (!empty($this->items))
				{?>
			<thead>
				<tr>
					<th class=''>
						<?php echo HTMLHelper::_('grid.sort', 'COM_TJUCM_ITEMS_ID', 'a.id', $listDirn, $listOrder); ?>
					</th>
					<!-- DPE - Hack - start to display columns -->
					<th class=''>
						<?php echo Text::_('COM_TJUCM_TIME_LOGGED'); ?>
					</th>
					<th class=''>
						<?php echo Text::_('COM_TJUCM_LOGGED_BY'); ?>
					</th>
					<!-- DPE - Hack - end -->

					<?php

					if (!empty($this->listcolumn))
					{
						foreach ($this->listcolumn as $col_name)
						{
							?>
							<th class='left'>
								<?php echo htmlspecialchars($col_name, ENT_COMPAT, 'UTF-8'); ?>
							</th>
							<?php
						}
					}

					if ($this->canEdit || $this->canDelete)
					{
						?>
						<th class="center">
							<?php echo Text::_('COM_TJUCM_ITEMS_ACTIONS'); ?>
						</th>
					<?php
					}
					?>
				</tr>
			</thead>
			<?php
				}
			}?>
			<?php
			if (!empty($this->items))
			{
			?>
			<tfoot>
				<tr>
					<td colspan="<?php echo isset($this->items[0]) ? count($this->items[0]->field_values)+3 : 10; ?>">
						<div class="pager" id="pagination">
							<?php echo $this->pagination->getPagesLinks(); ?>
							<hr class="hr hr-condensed"/>
						</div>
					</td>
				</tr>
			</tfoot>
			<?php
			}
			?>
			<tbody>
			<?php
			if (!empty($this->showList))
			{
				if (!empty($this->items))
				{
					foreach ($this->items as $i => $item)
					{

						$link = Route::_('index.php?option=com_tjucm&view=item&id=' . $item->id . "&client=" . $this->client . '&Itemid=' . $itemId, false);

						$editown = false;
						if ($this->canEditOwn)
						{
							$editown = ($user->id == $item->created_by ? true : false);
						}

						$deleteOwn = false;
						if ($this->canDeleteOwn)
						{
							$deleteOwn = ($user->id == $item->created_by ? true : false);
						}

						?>
						<tr class="row<?php echo $i % 2; ?>">
							<td>
								<?php
								if (isset($item->checked_out) && $item->checked_out)
								{
									echo HTMLHelper::_('jgrid.checkedout', $i, $item->uEditor, $item->checked_out_time, 'items.', $canCheckin);
								}
								?>
								<?php echo $this->escape($item->id); ?>
							</td>
							<td><?php echo HTMLHelper::date($item->created_date, Text::_('COM_DPE_TIME_FORMAT')); ?></td>
							<td><?php echo Factory::getUser($item->created_by)->name; ?></td>
							<?php
								if (!empty($item->field_values))
								{
									foreach ($item->field_values as $key => $field_values)
									{
										// Used to check field value contain json string
										$jsonValue = json_decode($field_values);

										if (json_last_error() === JSON_ERROR_NONE)
										{
											 $field_values = $jsonValue;
										}
										?>
										<td>
										<?php

										if (is_object($field_values))
										{
											foreach ($field_values as $subFormDataRow)
											{
												?>
												<table class="table table-bordered">
												<?php
												foreach ($subFormDataRow as $key => $subFormDataColumn)
												{
													?>
													<tr>
													<?php
													echo !empty($subFormDataColumn) ? '<td>' . $key . '</td><td>' . $subFormDataColumn . '</td>' : '';
													?>
													</tr>
													<?php
												}
												?>
												</table>
												<?php
											}
										}
										else
										{
											if (strlen($field_values) > 50)
											{
												echo wordwrap($field_values, 15, "\n", true);
											}
											else
											{
												if ($key == $clusterFieldId)
												{
													$cluster = ClusterCluster::getInstance($field_values);

													echo $this->escape($cluster->name);
												}
												elseif ($key == $ownershipFieldId)
												{
													 echo Factory::getUser((int) $field_values)->name;
												}
												else
												{
													echo $field_values;
												}
											}
										}
										?>
										</td>
										<?php
									}
								}

								if ($this->canEdit || $this->canDelete || $editown || $deleteOwn)
								{
									?>
									<td class="center">
									<?php
									if ($this->canEdit || $editown)
									{
										?>
										<a href="<?php echo 'index.php?option=com_tjucm&task=itemform.edit&id=' . $item->id . $appendUrl; ?>" class="btn btn-mini" type="button"><i class="icon-apply" aria-hidden="true"></i></a>
										<?php
									}
									if ($this->canDelete || $deleteOwn)
									{
										?>
										<a href="<?php echo 'index.php?option=com_tjucm&task=itemform.remove' . '&id=' . $item->id . $appendUrl . $csrf; ?>" class="btn btn-mini delete-button" type="button"><i class="icon-delete" aria-hidden="true"></i></a>
										<?php
									}
									?>
									</td>
								<?php
								}
								?>
						</tr>
					<?php
					}
				}
				else
				{
					?>
					<div class="alert alert-warning"><?php echo Text::_('COM_TJUCM_NO_DATA_FOUND');?></div>
				<?php
				}
			}
			else
			{
			?>
				<div class="alert alert-warning"><?php echo Text::_('COM_TJUCM_NO_DATA_FOUND');?></div>
			<?php
			}
			?>
			</tbody>
		</table>
	</div>
	<input type="hidden" name="task" value=""/>
	<input type="hidden" name="boxchecked" value="0"/>
	<input type="hidden" name="filter_order" value="<?php echo $listOrder; ?>"/>
	<input type="hidden" name="filter_order_Dir" value="<?php echo $listDirn; ?>"/>
	<?php echo HTMLHelper::_('form.token'); ?>
</form>
<?php
if ($this->canDelete)
{
	?>
	<script type="text/javascript">
	jQuery(document).ready(function () {
		jQuery('.delete-button').click(deleteItem);
	});

	function deleteItem()
	{
		if (!confirm("<?php echo Text::_('COM_TJUCM_DELETE_MESSAGE'); ?>"))
		{
			return false;
		}
	}
	</script>
<?php
}
