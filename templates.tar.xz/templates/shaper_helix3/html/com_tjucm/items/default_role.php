<?php
/**
 * @package    Com_Tjucm
 * @author     Techjoomla <extensions@techjoomla.com>
 * @copyright  Copyright (c) 2009-2019 TechJoomla. All rights reserved.
 * @license    GNU General Public License version 2 or later.
 */

// No direct access
defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Table\Table;
use Joomla\CMS\Router\Route;

HTMLHelper::_('behavior.tooltip');
HTMLHelper::_('behavior.multiselect');
HTMLHelper::_('formbehavior.chosen', 'select');
HTMLHelper::_('behavior.modal');

$app       = Factory::getApplication();
$menu      = $app->getMenu();
$itemId    = $menu->getActive()->id;
$user      = Factory::getUser();
$listOrder = $this->state->get('list.ordering');
$listDirn  = $this->state->get('list.direction');
$canEdit   = $user->authorise('core.type.edititem', 'com_tjucm.type' . $this->ucmTypeId);
$canDelete = $user->authorise('core.type.deleteitem', 'com_tjucm.type.' . $this->ucmTypeId);

$document = JFactory::getDocument();
$document->addScript(JUri::root() . 'media/com_dpe/js/tjucm.js');

JLoader::import('field', JPATH_ADMINISTRATOR . '/components/com_tjfields/tables');
$tjfieldsTablefield = Table::getInstance('field', 'TjfieldsTable', array());

JLoader::import('clusters', JPATH_ADMINISTRATOR . '/components/com_cluster/tables');
$clusterTableClusters = Table::getInstance('clusters', 'ClusterTable', array());

Text::script('COM_TJUCM_DELETE_MESSAGE');

$importLink = Route::_('index.php?option=com_dpe&view=import&tmpl=component&client=' . $this->client .'&Itemid=' . $itemId);
?>
<form action="" method="post" name="adminForm" id="adminForm">
	<!-- Filter layout-->
	<div class="row">
		<div class="col-md-6 role-master-list pull-right">
<!--
			<input
				type="text"
				name="filter[search]"
				id="filter_search"
				class="d-inline-block"
				onchange="this.form.submit();"
				placeholder="<?php echo JTEXT::_('COM_TJUCM_MASTER_ITEMS_SEARCH');?>"
				title="<?php echo JTEXT::_('COM_TJUCM_MASTER_ITEMS_SEARCH');?>"
				value="<?php echo $this->state->get('filter.search', '', 'STRING');?>"
				size="30">
-->

			<?php
			JFormHelper::addFieldPath(JPATH_ADMINISTRATOR . '/components/com_tjfields/models/fields/');
			$cluster            = JFormHelper::loadFieldType('cluster', false);
			$this->clusterArray = $cluster->getOptionsExternally();
			$this->clusterId    = $this->state->get('filter.cluster_id', '', 'INT');

			echo JHTML::_('select.genericlist', $this->clusterArray, 'cluster',
			'class="inputbox" onchange="this.form.submit();"', 'value', 'text', $this->clusterId
			);
			?>

			<div class="btn-group hidden-xs mx-10">
					<?php echo $this->pagination->getLimitBox(); ?>
			</div>

			<?php
			if ($this->allowedToAdd)
			{
				$appendUrl  = "";

				if (!empty($this->created_by))
				{
					$appendUrl .= "&created_by=" . $this->created_by;
				}

				if (!empty($this->client))
				{
					$appendUrl .= "&client=" . $this->client;
				}

				$config = Factory::getConfig();
				$url    = Route::_('index.php?option=com_tjucm&view=items' . $appendUrl, true);

				if ($config->get('sef') == 1)
				{
					$url = JRoute::_(JUri::base() . 'index.php?option=com_tjucm&view=items' . $appendUrl);
				}

				?>

				<a href="<?php echo Route::_('index.php?option=com_tjucm&task=itemform.edit&' . JSession::getFormToken() . "=1" . $appendUrl, false); ?>"
					class="ml-10 mr-15 btn btn-add btn-small pull-right">
					<i class="icon-plus"></i><?php echo Text::_('COM_TJUCM_ADD_ITEM'); ?>
				</a>

				<a href="javascript:void(0);" onclick="tjucm.itmes.openRopPopups('<?php echo addslashes(Route::_($importLink));?>')"
					class=" btn btn-add btn-small pull-right">
					<i class="fa fa-upload"></i>
					<?php echo Text::_('COM_TJUCM_IMPORT_RECORDS'); ?>
				</a>
			<?php
			}?>
		</div>
	</div>
	<div class="clearfix"></div>
	<hr class="hr-condensed"/>
	<!-- Filter layout end here-->

	<div class="row">
		<?php
		if (empty($this->showList) || empty($this->items))
		{
		?>
			<div class="alert alert-warning">
				<?php echo Text::_('COM_TJUCM_NO_DATA_FOUND');?>
			</div>
		<?php
		}
		else
		{
			?>
				<div class="col-xs-12">
					<table class="table table-striped" id="softwareList">
						<thead>
							<tr>
								<th>
									<?php echo HTMLHelper::_('grid.sort',  'COM_TJUCM_MASTER_ITEMS_ID', 'a.id', $listDirn, $listOrder);?>
								</th>
								<?php
								if (!empty($this->listcolumn))
								{
									foreach ($this->listcolumn as $col_name)
									{
										?>
										<th class='left'>
											<?php echo htmlspecialchars($col_name, ENT_COMPAT, 'UTF-8'); ?>
										</th>
										<?php
									}
								}

								if ($canEdit || $canDelete)
								{
									?>
									<th class="center">
										<?php echo Text::_('COM_TJUCM_ITEMS_ACTIONS');?>
									</th>
									<?php
								}
								?>
							</tr>
						</thead>
						<tbody>
							<?php
							foreach ($this->items as $i => $item)
							{
								$editSoftware = 'index.php?option=com_tjucm&task=itemform.edit&id=' . $item->id . '&client=' . $this->client . '&cluster_id=' . $item->cluster_id;
								?>
								<tr class="row<?php echo $i % 2; ?>">
									<td><?php echo $this->escape($item->id);?></td>
									<?php
									if (!empty ($item->field_values))
									{
										foreach ($item->field_values as $key => $field_value)
										{
											$tjfieldsTablefield->load(array('id' => (int) $key));

											if ($tjfieldsTablefield->type == 'cluster')
											{
												$clusterTableClusters->load(array('id' => (int) $item->cluster_id));
												$field_value = ucwords($clusterTableClusters->name);
											}

											?>
											<td>
												<?php echo (strlen($field_value) > 50) ?  wordwrap($field_value, 15, "\n", true) : $field_value;?>
											</td>
											<?php
										}
									}
									?>
									<td class="center hidden-xs  hidden-sm">
										<a href="<?php echo $editSoftware;?>&<?php echo JSession::getFormToken();?>=1">
											<i class="fa fa-pencil-square-o" aria-hidden="true"></i>
										</a>
									<?php
									if ($canDelete)
									{
									?>
										<a
											href="javascript:void(0);"
											onclick="tjucm.itmes.deleteMasterListItem('<?php echo $item->id;?>','<?php echo $this->client?>','<?php echo JSession::getFormToken();?>')"
											class="btn btn-mini delete-button" type="button">
											<i class="icon-delete" ></i>
										</a>
									<?php
									}
									?>
									</td>
								</tr>
								<?php
							}
							?>
						</tbody>
					</table>
				</div>

				<!--Pagination Here-->
				<div class="col-xs-12">
					<div class="pager" id="pagination">
						<?php echo $this->pagination->getPagesLinks(); ?>
						<hr class="hr hr-condensed"/>
					</div>
				</div>
			<?php
		}
		?>
	</div>
	<input type="hidden" name="filter_order" value="<?php echo $listOrder; ?>"/>
	<input type="hidden" name="filter_order_Dir" value="<?php echo $listDirn; ?>"/>
	<input type="hidden" name="client" value="<?php echo $this->client;?>"/>
	<?php echo HTMLHelper::_('form.token'); ?>
</form>
<script type="text/javascript">
 var baseurlPath = "<?php echo JUri::root();?>";
 var menuItemId  = "<?php echo $itemId;?>";
 tjucm.itmes.init();
</script>
