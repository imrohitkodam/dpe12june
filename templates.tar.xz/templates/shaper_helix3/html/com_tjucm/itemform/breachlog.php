<?php
/**
 * @version    SVN: <svn_id>
 * @package    Com_Tjucm
 * @author     Techjoomla <extensions@techjoomla.com>
 * @copyright  Copyright (c) 2009-2019 TechJoomla. All rights reserved.
 * @license    GNU General Public License version 2 or later.
 */

// No direct access
defined('_JEXEC') or die;
use Joomla\CMS\Language\Text;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Table\Table;

HTMLHelper::_('behavior.keepalive');
HTMLHelper::_('bootstrap.tooltip');
HTMLHelper::_('behavior.formvalidator');
HTMLHelper::_('formbehavior.chosen', 'select');
HTMLHelper::_('jquery.token');

/*
* Script to show alert box if form changes are made and user is closing/refreshing/navigating the tab
* without saving the content
*/
HTMLHelper::script('media/com_tjucm/js/vendor/jquery/jquery.are-you-sure.js');

/*
* Script to show alert box if form changes are made and user is closing/refreshing/navigating the tab
* without saving the content on iphone|ipad|ipod|opera
*/
HTMLHelper::script('media/com_tjucm/js/vendor/shim/ays-beforeunload-shim.js');

HTMLHelper::script('administrator/components/com_tjfields/assets/js/tjfields.js');

// Call js file to update the link to ticket 
HTMLHelper::script('media/com_dpe/js/logsticket.js');

// Load admin language file
$lang = Factory::getLanguage();
$lang->load('com_tjucm', JPATH_SITE);

$jinput                    = Factory::getApplication();
// $jinput->addScript(Uri::root() . 'media/system/js/showon-es5.js');
// $jinput->addScript(Uri::root() . 'media/system/js/showon.js');
$editRecordId              = $jinput->input->get("id", '', 'INT');
$baseUrl                   = $jinput->input->server->get('REQUEST_URI', '', 'STRING');
$calledFrom                = (strpos($baseUrl, 'administrator')) ? 'backend' : 'frontend';
$layout                    = ($calledFrom == 'frontend') ? 'default' : 'edit';
$fieldsets_counter_deafult = 0;
$setnavigation             = false;

if ($this->item->id)
{
	$itemState = ($this->item->draft && ($this->allow_auto_save || $this->allow_draft_save)) ? 1 : 0;
}
else
{
	$itemState = ($this->allow_auto_save || $this->allow_draft_save) ? 1 : 0;
}

// DPE - Hack - Start - Add new confirmation mesage
Text::script('COM_TJUCM_ITEMFORM_SUBMIT_DPE_CONFIRMATION');
// DPE - Hack - End

Factory::getDocument()->addScriptDeclaration('
	jQuery(function() {
		jQuery("#item-form").areYouSure();
	});

	jQuery(document).ready(function ()
	{
		jQuery("#item-form .nav-tabs li a").first().click();
	});

	Joomla.submitbutton = function (task)
	{
		if (task == "itemform.cancel")
		{
			Joomla.submitform(task, document.getElementById("item-form"));
		}
		else
		{
			if (task != "itemform.cancel" && document.formvalidator.isValid(document.id("item-form")))
			{
				Joomla.submitform(task, document.getElementById("item-form"));
			}
			else
			{
				alert("' . $this->escape(Text::_("JGLOBAL_VALIDATION_FORM_FAILED")) . '");
			}
		}
	};
');

	// DPE - Hack - Start - To add Jlike plugin
		if (!empty($this->id) && $this->client == 'com_tjucm.breachlog')
		{
			
			PluginHelper::importPlugin('content', 'jlike_dpe');
			$this->event = new stdClass;
			$results = Factory::getApplication()->triggerEvent('onContentAfterDisplay', array('com_tjucm.itemform', &$this->item , &$this->params));
			$this->event->afterDisplayContent = trim(implode("\n", $results));
		}
	// DPE - Hack - End

// Get Current url for notification manager widget

$extraParams = Uri::getInstance()->toString(array('query'));
$extraParams = str_replace('?', '&', $extraParams);
$input       = $jinput->input;

$currentUrl =  'index.php?option=' . $input->get('option') . '&view=' . $input->get('view') . $extraParams .'&Itemid=' . $input->get('Itemid');
?>
<form action="<?php echo Route::_('index.php');?>" method="post" enctype="multipart/form-data" name="adminForm" id="item-form" class="sar-breach-create-page form-validate ucm-form-styling">
	<?php
	if ($this->allow_auto_save == '1')
	{
	?>
	<div class="alert alert-info" style="display:none;" id="tjucm-auto-save-disabled-msg">
		<div class="msg float-start">
			<div>
				<?php echo Text::_("COM_TJUCM_MSG_FOR_AUTOSAVE_FEATURE_DISABLED"); ?>
			</div>
		</div>
		<a href="javascript:void();" class="close float-end" data-dismiss="alert">×</a>
		<div class="clearfix"></div>
	</div>
	<?php
	}
	?>
	<div>
		<div class="row-fluid">
			<div class="span10 form-horizontal">
		<fieldset>
			<input type="hidden" name="jform[id]" id="recordId" value="<?php echo $editRecordId; ?>" />
			<input type="hidden" name="jform[ordering]" value="<?php echo $this->item->ordering; ?>" />
			<input type="hidden" name="jform[state]" value="<?php echo $this->item->state;?>" />
			<input type="hidden" id="ucm-client" name="jform[client]" value="<?php echo $this->client;?>" />
			<input type="hidden" name="jform[checked_out]" value="<?php echo $this->item->checked_out; ?>" />
			<input type="hidden" name="jform[checked_out_time]" value="<?php echo $this->item->checked_out_time; ?>" />
			<input type="hidden" name="itemState" id="itemState" value="<?php echo $itemState; ?>"/>
			<?php echo $this->form->renderField('created_by'); ?>
			<?php echo $this->form->renderField('created_date'); ?>
			<?php echo $this->form->renderField('modified_by'); ?>
			<?php echo $this->form->renderField('modified_date'); ?>
		</fieldset>
			</div>
		</div>
	<?php
	if ($this->form_extra)
	{
		?>

		<?php
		//  DPE - Hack - Code to display the form
		echo $this->loadTemplate('extrafieldslog');
		?>

		<?php
	}
	?>
	<!-- DPE - Hack - Removed extra messages and added design ( Div's) -->

	<div id="draft_msg" class="alert alert-success" style="display: none;">
		<a class="close" data-dismiss="alert">×</a>
		<?php echo Text::_("COM_TJUCM_MSG_ON_DRAFT_FORM"); ?>
	</div>

	<div class="form-actions buttons-mobile-view border-0 bg-none">
		<?php
		// Show next previous buttons only when there are mulitple tabs/groups present under that field type
		$fieldArray = $this->form_extra;

		foreach ($fieldArray->getFieldsets() as $fieldName => $fieldset)
		{
			if (count($fieldArray->getFieldsets()) > 1)
			{
				$setnavigation = true;
			}
		}

		if (isset($setnavigation) && $setnavigation == true)
		{
			?>
				<!-- <button type="button" class="btn btn-primary mt-20" id="previous_button" >
					<i class="icon-arrow-left-2"></i>
					<?php echo Text::_('COM_TJUCM_PREVIOUS_BUTTON'); ?>
				</button>
				<button type="button" class="btn btn-primary mt-20" id="next_button" >
					<?php echo Text::_('COM_TJUCM_NEXT_BUTTON'); ?>
					<i class="icon-arrow-right-2"></i>
				</button> -->
			<?php
		}

		if ($calledFrom == 'frontend')
		{
			?>
			<div class="row">
				<div class="row">
					<div class="col-sm-9  text-end">
						<?php
						if (($this->allow_auto_save || $this->allow_draft_save) && $itemState)
						{
							?>
							<input type="button" class="btn btn-default px-25 mobile-space" id="tjUcmSectionDraftSave"
							value="<?php echo Text::_("COM_TJUCM_SAVE_AS_DRAFT_ITEM"); ?>"
							onclick="tjUcmItemForm.saveUcmFormData();" />
							<?php
						}
						?>
						<input type="button" class="btn btn-primary mobile-space" value="<?php echo Text::_('COM_TJUCM_SAVE_ITEM'); ?>" id="tjUcmSectionFinalSave" onclick="tjUcmItemForm.saveUcmFormData();" />

						<input type="button" class="btn btn-primary mobile-space" value="<?php echo Text::_("COM_TJUCM_SAVE_CLOSE_ITEM"); ?>" id="tjUcmSectionFinalSaveClose" onclick="tjUcmItemForm.saveUcmFormData();" />

						<input type="button" class="btn btn-warning mobile-space" value="<?php echo Text::_("COM_TJUCM_CANCEL_BUTTON"); ?>" onclick="Joomla.submitbutton('itemform.cancel');" />
					</div>
				</div>
			</div>
			<div class="clearfix"></div>
			<?php
		}
		?>
	</div>
	<input type="hidden" name="layout" value="<?php echo $layout ?>"/>
	<input type="hidden" name="task" value="itemform.save"/>
	<input type="hidden" name="form_status" id="form_status" value=""/>
	<input type="hidden" name="tjucm-autosave" id="tjucm-autosave" value="<?php echo $this->allow_auto_save;?>"/>
	<input type="hidden" name="tjucm-bitrate" id="tjucm-bitrate" value="<?php echo $this->allow_bit_rate;?>"/>
	<input type="hidden" name="tjucm-bitrate_seconds" id="tjucm-bitrate_seconds" value="<?php echo $this->allow_bit_rate_seconds;?>"/>

	<input type="hidden" name="url" id="url" value="<?php echo $currentUrl;?>"/>
	<input type="hidden" name="element" id="element" value="<?php echo $this->client;?>"/>
	<input type="hidden" name="element_id" id="element_id" value="<?php echo $this->id;?>"/>
	<input type="hidden" name="cluster_id" id="cluster_id" value="<?php echo $this->item->cluster_id;?>"/>
	<input type="hidden" name="isDraft" id="isDraft" value="1"/>
	<?php echo HTMLHelper::_('form.token'); ?>

		<?php
		// DPE - Hack - Start - To show comments

		if ($this->event->afterDisplayContent && !empty($this->id) && $this->client == 'com_tjucm.breachlog')
		{
			?>
			<div class="col-xs-12">
				<?php echo $this->event->afterDisplayContent;?>
			</div>
			<?php
		}
		?>
		<input type="hidden" name="custForm" id="custForm" value="1"/>
		<!--  DPE - Hack - End  - Show comments-->
</form>


