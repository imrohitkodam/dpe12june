<?php
/**
 * @version    SVN: <svn_id>
 * @package    Com_Tjucm
 * @author     Techjoomla <extensions@techjoomla.com>
 * @copyright  Copyright (c) 2009-2017 TechJoomla. All rights reserved.
 * @license    GNU General Public License version 2 or later.
 */

// No direct access
defined('_JEXEC') or die;
use Joomla\CMS\Language\Text;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\User\User;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;

HTMLHelper::_('behavior.formvalidation');

$lang->load('com_tjfields', JPATH_SITE, 'en-GB', true);
Text::script('COM_TJFIELDS_FILE_ERROR_MAX_SIZE');
Text::script('COM_TJFIELDS_FILE_DELETE_CONFIRM');

$app = Factory::getApplication();

$fieldsets_counter = 0;
$layout            = $app->input->get('layout');
$baseUrl           = $app->input->server->get('REQUEST_URI', '', 'STRING');
$calledFrom        = (strpos($baseUrl, 'administrator')) ? 'backend' : 'frontend';
$layout            = ($calledFrom == 'frontend') ? 'default' : 'edit';
$link = 'index.php?option=com_tjucm&view=items&client=com_tjucm.breach-log';


if ($this->form_extra)
{
	// Iterate through the normal form fieldsets and display each one
	$fieldArray = $this->form_extra;
	$fieldSets  = $fieldArray->getFieldsets();
	$newTab     = '';

	foreach ($fieldSets as $fieldName => $fieldset)
	{
		$addTab = 0;

		if (count($fieldSets) > 1)
		{
			if ($fieldsets_counter == 0)
			{
				echo HTMLHelper::_('bootstrap.startTabSet', 'tjucm_myTab');
			}

				$fieldsets_counter ++;

				if (count($fieldArray->getFieldset($fieldset->name)))
				{
					foreach ($fieldArray->getFieldset($fieldset->name) as $field)
					{
						if (!$field->hidden)
						{
							$addTab = 1;
						}
					}

					if ($addTab)
					{
						$tabName = JFilterOutput::stringURLUnicodeSlug(trim($fieldset->name));
						echo HTMLHelper::_("bootstrap.addTab", "tjucm_myTab", $tabName, $fieldset->name);
					}
				}
		}
		?>
		<div class="section-title visible-print"><h3><?php echo $fieldset->name;?></h3></div>

		<div class="form-horizontal col-xs-12 custom-form-fields">
		<?php
		// Iterate through the fields and display them
		foreach ($fieldArray->getFieldset($fieldset->name) as $field)
		{
			if (!$field->hidden)
			{
				?>
				<div class="col-xs-12 col-md-12 <?php echo $cssChecklist;?>">
					<div class="form-group">
						<div class="col-sm-4">
								<?php echo $field->label; ?>
						</div>
						<div class="col-sm-5 custom-calender">
							<?php echo $field->input; ?>
						</div>
						<?php
						// TODO :- Check and remove
						if ($field->type == 'File')
						{
							?>
							<script type="text/javascript">
								jQuery(document).ready(function ()
								{
									var fieldValue = "<?php echo $field->value; ?>";
									var AttrRequired = jQuery('#<?php echo $field->id;?>').attr('required');
									if (typeof AttrRequired !== typeof undefined && AttrRequired !== false)
									{
										if (fieldValue)
										{
											jQuery('#<?php echo $field->id;?>').removeAttr("required");
											jQuery('#<?php echo $field->id;?>').removeClass("required");
										}
									}
								});
							</script>
						<?php
						}
						?>
					</div>
				</div>
			<?php
			}
		}
		?>
		</div>
		<?php
		if (count($fieldArray->getFieldsets()) > 1)
		{
			$setnavigation = true;

			if (isset($setnavigation) && $setnavigation === true && !empty($this->allow_draft_save) && $this->client == 'com_tjucm.breach-log')
			{
				if ($fieldsets_counter == 1 && $newTab != $tabName)
				{
					$newTab = $tabName;
				?>
				<div class="col-sm-5 col-sm-offset-4 pull-right mt-10">
					<button type="button" class="btn btn-primary" id="next_button" onclick="itemformactions('tjucm_myTab','next')">
						<?php echo Text::_('COM_TJUCM_NEXT_BUTTON'); ?>
						<i class="icon-arrow-right-2"></i>
					</button>
					<a class="btn btn-default ml-20" href="<?php echo Route::_($link); ?>" title="<?php echo Text::_('JCANCEL'); ?>">
						<?php echo Text::_( 'JCANCEL'); ?>
						</a>
					</div>
				<?php
				}
				elseif ($fieldsets_counter == count($fieldArray->getFieldsets()) && $newTab != $tabName)
				{
					if ($calledFrom == 'frontend')
					{
						?>
						<div class="col-sm-5 col-sm-offset-4 pull-right mt-10">
							<input type="button" class="btn btn-primary btn-submit" value="<?php echo Text::_("COM_TJUCM_SAVE_ITEM"); ?>"
							id="finalSave" onclick="steppedFormSave(this.form.id, 'save');" />
							<a class="btn btn-default ml-20" href="<?php echo Route::_($link); ?>" title="<?php echo Text::_('JCANCEL'); ?>">
							<?php echo Text::_( 'JCANCEL'); ?>
							</a>
						</div>
						<?php
					}
				}
				else
				{
					if ($fieldsets_counter == count($fieldArray->getFieldsets()) - 1)
					{
						$newTab = $tabName;
					}
					?>
					<div class="col-sm-5 col-sm-offset-4 pull-right mt-10">
						<button type="button" class="btn btn-primary" id="next_button" onclick="itemformactions('tjucm_myTab','next')">
							<?php echo Text::_('COM_TJUCM_NEXT_BUTTON'); ?>
							<i class="icon-arrow-right-2"></i>
						</button>
						<a class="btn btn-default ml-20" href="<?php echo Route::_($link); ?>" title="<?php echo Text::_('JCANCEL'); ?>">
						<?php echo Text::_( 'JCANCEL'); ?>
						</a>
				</div>
				<?php
				}
			}
		}

		if (count($fieldArray->getFieldset($fieldset->name)))
		{
			if ($addTab)
			{
				echo HTMLHelper::_("bootstrap.endTab");
			}
		}

		if ($fieldsets_counter == 0)
		{
			echo HTMLHelper::_('bootstrap.startTabSet');
		}
	}
}
else
{
	?>
	<div class="alert alert-info">
		<?php echo Text::_('COM_TJLMS_NO_EXTRA_FIELDS_FOUND');?>
	</div>
	<?php
}
<script>jQuery(document).ready(function($){
				 // Temp solution for conditional field

				var dataShowonFields = jQuery("#item-form").find("div[data-showon]");
					
					dataShowonFields.each(function() {
						var value = jQuery(this).data("showon");
						var fieldName = value[0].field;
						var signVal = value[0].sign;

						var inputValue = jQuery("select[name=\'"+ fieldName +"[]\']").val();
						if (inputValue == null && (signVal == "!="))
						{
							jQuery(this).css("display", "");
						}
					});
					jQuery("select[multiple]").on("change", function () {

						dataShowonFields.each(function() {
						var value = jQuery(this).data("showon");
						var fieldName = value[0].field;
						var inputValue = jQuery("select[name=\'"+ fieldName +"[]\']").val();
						var signVal = value[0].sign;
                                            
						if (inputValue == null && signVal == "!=")
						{ console.log("hi");
							jQuery(this).css("display", "");
						}
					});

						});
				});</script>