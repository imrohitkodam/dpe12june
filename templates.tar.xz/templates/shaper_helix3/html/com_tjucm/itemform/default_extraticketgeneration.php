<?php

	$fieldTable= $this->fieldTable;
	$ticketConditionData = $this->ticketConditionData;
	$fieldTableLink = $this->fieldTableLink;
?>

<script>

jQuery(document).ready(function(){

	if ("<?php echo $fieldTable->id?>".length > 1)
	{
		jQuery('#jform_'+"<?php echo $ticketConditionData->linkField?>").attr('readonly','readonly');

		if (jQuery('#jform_'+"<?php echo $ticketConditionData->linkField?>").val())
		{
			jQuery('.ticketbtn').addClass('d-none');
		}
	}
	
});
	function updateLinkField()
	{		
			if ("<?php echo $fieldTable->id?>".length > 1)
			{
				var recordId = jQuery('#recordId').val();
				logticket.afterSaveLinkFieldUpdate(recordId+','+ <?php echo ($fieldTableLink->id)?$fieldTableLink->id:0?>)
			}
	}
	
</script>