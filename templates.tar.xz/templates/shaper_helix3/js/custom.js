jQuery(document).ready(function() {
    jQuery('.sp-megamenu-parent>li' || '.sp-dropdown-sub .sp-dropdown-items>li').hover(function() {
        var parentMenuItem = jQuery(this);
        var parentMenuName = parentMenuItem.find('a').text();
        var parentMenucount = (parentMenuItem.find('a').length) - 1;
        var subMenuNames = [];
        var subMenuCount = 0;

        // var subParentmenuItem =jQuery('.sp-dropdown-main .sp-dropdown-inner .sp-dropdown-items .sp-menu-item.sp-has-child .sp-dropdown-sub .sp-dropdown-inner .sp-dropdown-items').find('li').length;
       

        parentMenuItem.find('.sp-has-child > .sp-dropdown-sub > .sp-dropdown-inner > .sp-dropdown-items > .sp-menu-item').each(function() {
            var subMenuName = jQuery(this).find('a').text();
            subMenuNames.push(subMenuName);
            subMenuCount++;
        });
        //console.log("subParentmenuItem",subParentmenuItem);
        //console.log("parentMenuName=", parentMenuName);
        //console.log("parentMenucount=", parentMenucount);

        //console.log("subMenuName=", subMenuNames.join(","));
        //console.log("subSubMenuCount=", subMenuCount);
        var totalcount = parentMenucount - subMenuCount;
        //console.log("total=", totalcount);
        if (totalcount > 5 || totalcount < 0) {
            
            jQuery(".sp-megamenu-parent .sp-dropdown .sp-dropdown-items").css('grid-template-columns', 'repeat(2, 1fr)');
        //     if(subMenuCount > 5){
        //         jQuery(".sp-dropdown-main .sp-dropdown-inner .sp-dropdown-items .sp-menu-item.sp-has-child .sp-dropdown-sub .sp-dropdown-inner .sp-dropdown-items .sp-menu-item").css('grid-template-columns', 'repeat(2, 1fr)');
        //     }
        //    else{
        //         jQuery(".sp-dropdown-main .sp-dropdown-inner .sp-dropdown-items .sp-menu-item.sp-has-child .sp-dropdown-sub .sp-dropdown-inner .sp-dropdown-items .sp-menu-item").css('grid-template-columns', 'repeat(1, 1fr)');
        //     }

        } else {
            jQuery(".sp-megamenu-parent .sp-dropdown .sp-dropdown-items").css('grid-template-columns', 'repeat(1, 1fr)');
        }
    });
});
